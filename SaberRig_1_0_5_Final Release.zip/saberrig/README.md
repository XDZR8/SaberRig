# SaberRig 1.0.5

> **Source documentation update (1.0.5):** Developer comments and visible
labels have been clarified. Historical rig/manifest identifiers remain
unchanged. All profiles stay discoverable in the sidebar; incompatible
profile controls remain informational. See `DEVELOPER_NOTES.md` for module
responsibilities, safety boundaries and the Blender regression checklist.


Native Blender 5.1.1 rigging add-on with profile-based preparation and animation controls.

## Installation

Install `SaberRig_1_0_5_Code_Documentation_Cleanup.zip` from **Edit → Preferences → Add-ons → Install from Disk**. Do not unzip before installing. Restart Blender, then open **3D Viewport → N → SaberRig**.

The logo is bundled in `saberrig/assets/SaberRig_icon.png` and loaded as an optional Blender preview. It has no external dependency.

## Interface

- **Prepare SaberRig** detects the selected armature and invokes the appropriate preparation.
- **General / MMD** offers the shared humanoid rigging controls.
- **Uma Musume** shows MMD-hybrid tools and the existing secondary-motion controls.
- **FGO Arcade** contains the prepared IK/FK controls, Knee Follow, thigh and arm auxiliary bindings, planted-foot squat and torso lean.
- **Arknights: Endfield Biped** has an isolated, guarded AE FK foundation (25 FK controls + 23 independent non-deforming mechanisms), and optional per-limb FK/IK controls for both arms and legs. Endfield Segmented retains its earlier experimental generic tools.
- **QA & Reports** is nested under FGO Arcade. Historical diagnostic operator implementations remain in the engine for compatibility, but no Legacy Tools panel is shown.

### Profile discovery in 1.0.5

Every profile's sidebar section stays visible with any selected armature (or none).
For a non-matching profile, the section shows a disabled feature list instead
of hiding its options. Only a compatible armature displays operational controls;
the preview cannot trigger rig changes, audits, or profile-specific operators.
The FGO Animation Controls, Pelvis/Knees/Pose, and QA/Reports subpanels also
remain discoverable when another profile is selected.


## Package layout

```
saberrig/
    __init__.py      Blender metadata, operator registration and lifecycle
    engine.py        Profile detection, rig creation, animation and QA operators
    ae_biped.py      Isolated Endfield Biped FK foundation, audit and removal
    ae_collection_org.py  Reversible AE source bone collection organization
    ae_ik.py         Preserved E1.4 left arm FK/IK solver
    ae_ik_arm_r.py   Right arm FK/IK extension (E1)
    ae_ik_leg_l.py   Left leg FK/IK extension with toe following (E1)
    ae_ik_leg_r.py   Right leg FK/IK extension with toe following (E1)
    ae_auto_attachments.py  AE Build auto-detection / restoration of validated rigid bindings
    ae_si_attachments.py  E2.3 Si binding implementation and legacy metadata reader
    diagnostics/     Read-only AE IK and auto-attachment diagnostic scripts
    ui.py            Native sidebar panels and bundled logo handling
    assets/
        SaberRig_icon.png
```

## Compatibility and scope

The user-facing add-on version is **1.0.5**.

This revision retains the existing user-facing rigging tools and algorithms. Fix1.2 updates the installer layout and the Bake + Remove failure reporting. Blender runtime behavior still requires testing in Blender 5.1.1, including fresh installation and a prepared FGO rig.


## E2.6 — AE Rigid Attachment Manifest Integrity (experimental)

This maintenance release fixes **ownership synchronization**, not the attachment
mapping. The existing E2.5 exact eight-name Si profile, FK/IK solvers and
Foot Follow implementation are unchanged. **Blender 5.1.1 native validation is
still required.**

- **Build and Sync use the same commit:** `ae_auto_attachments.apply` writes
  the `auto_rigid_attachments` record to the AE foundation manifest. A legacy
  E2.3/E2.4 pilot binding is adopted without reparenting it a second time.
  The main AE panel offers **Sync Existing Rigid Attachments** for these
  legacy-bound rigs and distinguishes them from AE-managed bindings.
- **Rollback ownership:** if a *new* eight-object binding succeeds but its
  manifest commit fails, the new binding and the ownership record are rolled
  back together (best effort, with explicit incomplete-recovery errors).
  An already-existing E2.3 pilot is never removed by a failed Build.
- **Remove:** successful `lod0` restoration clears AE attachment ownership
  metadata immediately, before source-bone/constraint deletion. This prevents
  a stale `rigid:auto_manifest` after an early Remove failure. If release of
  that metadata itself fails, the code attempts to recover the previous
  bound state. **Removal of the FK/IK rig is still not a fully transactional
  operation.** If later collection/bone removal fails, reopen a saved copy.
- Direct F3 legacy **Apply** uses the unified ownership path, and direct
  **Restore** now reports a missing/invalid armature as a Blender message
  rather than throwing an uncaught exception.
- A read-only E2.6 probe is bundled at
  `diagnostics/SaberRig_AE_Auto_Rigid_E2_6_ReadOnly_Probe.py`. Capture one
  JSON in neutral pose and another with pelvis and spine bent to inspect
  object/parent behavior. The seven cloth/VFX mappings to `Bip001` remain
  **experimental**. Head/Root/Master tests alone do not establish the
  correct anatomical parenting under torso and pelvis motion.

**Partial Si signatures remain fail-closed** in this release: Build aborts
before creating any bone rather than silently guessing. A user-configurable
skip-for-auxiliaries mode is deferred pending Blender E2 and safety design.
The world matrix tolerance remains the original absolute `3e-4`; this is
not yet certified for rigs with extreme scale differences. Actions, NLA,
drivers, animation bake and production-ready teardown are outside this patch.

## E2.5 — AE Build Automatic Rigid Attachments (experimental)

**The Endfield Biped Build now includes validated rigid eye/accessory attachment
migration automatically.** The former Si-specific UI subpanel is removed.
The model-neutral dispatcher (`ae_auto_attachments.py`) currently recognizes
only the **eight exact, already-audited Si objects** from E2.3, identified by
names, armature parenting, `lod0` original bone binding, rigid-mesh properties
and required target bones. Other AE models, including Wulfa, Arcane and
Tangtang, are **not guessed or rebound**. They are left unchanged until
validated target maps exist. A partial/unsafe Si signature causes Preflight /
Build to stop *before* any AE bone creation.

- New unbuilt Si `.blend`: run **Preflight**, then **Build AE Controls** as
  normal. The Build creates FK as before, verifies native pose, and applies
  the approved eight rigid bindings automatically. A separate saved E2.3
  attachment manifest records original transforms/parents; the AE manifest
  also records `auto_rigid_attachments`. If application fails, Build attempts
  attachment rollback **before** rolling back the AE foundation. A rollback
  failure leaves the rig in place and reports recovery as incomplete.
- Existing Si `.blend` with all IK already installed: **do not rebuild**. The
  already-applied E2.3 migration is recognized automatically. If it was never
  applied, use **Arknights: Endfield → Sync AE Rigid Attachments (Existing Rig)**
  inside the **main AE panel** once. This does not rebuild FK/IK.
- **Remove AE Controls** (after removing IK and restoring the FK baseline)
  attempts to restore the original `lod0` bone parenting automatically,
  including when the old E2.3 pilot manifest is present. If attachments or
  transforms have changed, it refuses destructive removal. As in E2.4,
  full transactional rollback of all source-bone deletion steps is not
  guaranteed; keep a separate `.blend` backup.
- The legacy E2.3 operators are retained for diagnosing old files but no
  longer have a visible character-specific panel. Direct legacy restore is
  guarded for automatic Build-owned attachment metadata.

**Not implemented:** eye gaze / pupil control, shader material repair, new
rigid-binding rules for unvalidated character variants. Native Blender 5.1.1
visual and undo/load tests are required; offline tests do not certify Blender
bone-parent evaluation or real-world FK/IK behavior. Read-only E2.5 probe:
`diagnostics/SaberRig_AE_Auto_Rigid_E2_5_ReadOnly_Probe.py`.

## E2.3 legacy — Manual Si Rigid Attachments (historical reference)

The following steps describe E2.3 only; **do not follow them for E2.5**.


This candidate **adds** the reviewed Si E2.3 standalone pilot to the E2.2
SaberRig add-on. **All four FK/IK solvers and engine.py are unchanged.**
It is an opt-in, **Si-only** migration; nothing runs automatically on Build.
The goal is to make the rigid iris and SaberShader eye-plane children follow
`face_Head`, and two cloth plus five VFX meshes follow `Bip001`, instead of
the separate `lod0` / `Mesh_all` branch. This is not an eye-tracking feature,
shader fix, or established compatibility with Arcane/Tangtang.

On a separately saved **copy** of Si's working AE Biped `.blend`:

1. Install this complete ZIP in Blender 5.1.1 and restart (disable older SaberRig).
2. Select Si's armature, open **N → SaberRig → Arknights: Endfield →
   Si Eyes & Rigid Attachments (E2.3)**.
3. Run **Audit Si Attachments**, which writes a read-only JSON to the OS temp
   folder. The eight expected original meshes must have bone parent `lod0`,
   no Armature Modifier, no object constraints, no vertex groups or Actions.
4. In the calibrated pose, press **Bind Si Eyes + Rigid Parts**. It records a
   persistent manifest and verifies world transforms within `3e-4`.
5. Test Head, Root, Master and the four IK chains, as well as the expression
   eye planes and white VFX meshes. If misaligned, use **Restore Original Si
   Bindings** after returning to the exact pose used at Apply.

The Restore operator supports a manifest created by the older standalone E2.3
script. It guards against changed source bindings and armature/parent poses;
it attempts rollback if restoration fails. **Remove AE Controls refuses to run
while an Si attachment manifest exists**. No bones, skinning, constraints,
materials or modifiers are intentionally altered. If an error reports partial
rollback, reopen your saved copy rather than editing the partially changed rig.

**QA limitations:** static regression only. Native Blender 5.1.1 and visual
E2 verification of the attachment binding are required before considering this
production-ready. The destination assignments for VFX are hypotheses.

## AE Multimodel — E2.2 Root Wrapper Preflight (Si import, 2026-11-19)

**Scope: Blender 5.1.1 candidate, not native-E2 certified.** This package
changes only `ae_biped.py` and documentation from Full FK/IK E1. It keeps the
existing Wulfa FK and all four IK solver modules unchanged.

A clean Si FBX import may produce the following **bone hierarchy** in a single
armature:

```
chr_0036_jsspsi_postmodel
  └─ Root
      └─ Bip001
          └─ Bip001_Pelvis  [and original anatomical descendants]
```

The original Wulfa form (`Bip001` without a parent) is also accepted. E2.2
permits `Root -> Bip001` and exactly one additional root-level
`chr_*_postmodel -> Root -> Bip001` chain. Other root parent shapes still fail
closed. The **23 canonical anatomical roles and their 22 internal parent
relationships remain strictly validated**. Wrapper bones must have finite
pose matrices, existing pose channels and no constraints; global Action/NLA/
drivers restrictions remain intact. No wrapper is renamed, reparented or given
new constraints.

`source_root_wrappers` is an optional manifest inventory. Builds generated with
E2.2 store the verified wrapper names; Audit will reject structural changes or
new constraints on them. Existing Wulfa manifests and optional IK extensions
are backward-compatible; this update does **not** require rebuilding an
already working Wulfa rig.

**Testing the user-supplied Si(1).blend:** make a uniquely named copy of the
original `.blend`, install the E2.2 ZIP, restart Blender, select Si's armature
and run the bundled `diagnostics/SaberRig_AE_Si_E2_2_ReadOnly_Probe.py` in
Scripting before building. Check **Preflight**. If it passes, execute **Build
AE Controls** on the saved copy. The constructor will automatically reject a
neutral-pose change larger than `1e-4` on the 23 source roles and attempt
rollback if it fails. Run the diagnostic again and compare both JSON files
using `diagnostics/compare_si_e2_2_snapshots.py` from the separately bundled
QA Kit. Expected bone count: **551 -> 599** for the 48-bone FK foundation.
Do not install IK until the FK build and source-mesh deformation have been
verified. If rollback is reported incomplete, re-open the original saved copy
rather than re-running Build or Remove on a partial rig.

Validation: structural `.blend` inspection plus Python stub QA; the absence of
Blender execution means no claim of certified FK/IK or mesh behavior on Si.

## AE Biped — Automatic Bone Collection Organization (2026-11-19 E1)

On successful **Build AE Controls**, SaberRig now automatically organizes
original Endfield Biped bones in two additional Bone Collections:

- **SaberRig AE Source Deform**: the 23 known original anatomical source roles;
  hidden by default.
- **SaberRig AE Source Auxiliary**: all other original bones (e.g. twist,
  corrective, hair, clothing, facial bones), hidden by default. For the
  inspected Wulfa model: 308 bones if the source armature still has 331 bones.
- **SaberRig AE Biped Controls**: all 25 generated FK controls; visible.
- **SaberRig AE Biped Mechanism**: all 23 generated mechanism bones; hidden.

**IMPORTANT:** A bone can belong to multiple Bone Collections. Adding it to a
hidden collection does NOT necessarily hide it if it also belongs to a visible
one. SaberRig therefore records the original membership lists for every
original bone in the existing `saberrig_ae_biped_foundation` JSON manifest;
it reassigns those original bones into exactly one AE source category during
organization. **Existing user Bone Collection objects are never removed or
renamed, and their visibility flags are not changed.** Their exact memberships
are restored on successful **Remove AE Controls**, even if a bone originally
belonged to several collections or none. The native skeleton, constraints,
rest matrices, deformation flags, animation and mesh weights are not altered
by the collection organization itself.

The Endfield sidebar adds **Show Controls Only**, **Show / Hide Auxiliary
Bones**, **Show / Hide Original Skeleton** (the 23 main original sources). It
does not expose mechanism bones by default. Collection visibility changes are
independent of pose state.

### Existing AE foundation: in-place upgrade

If an earlier Imported Pose Fix E1 control foundation has **already been
built** in your saved `.blend`, install the new ZIP with the earlier version
disabled and restart Blender. Open an independently saved copy of the `.blend`.
Do **not** build twice. With the armature `Root` selected, go to **N → SaberRig
→ Arknights: Endfield** and click **Organize AE Bone Collections**. This only
changes source Bone Collection assignments and UI visibility. It neither
rebuilds nor recalibrates the controls. The existing calibrated source manifest
remains compatible.

If your rig's Bone Collection membership has been manually changed after
organization, audit and removal will refuse unsafe changes rather than silently
discard the edits. Restore the exact AE source-category memberships before
removing the controls, or use Blender Undo / the duplicated `.blend`. If the
add-on reports **rollback incomplete**, stop and inspect before retrying.

### E2 test sequence on Wulfa

1. Save a **new copy** of the Wulfa `.blend`; disable the previous SaberRig ZIP.
2. Install this ZIP, restart Blender, and select armature `Root`.
3. If an AE rig already exists, use **Organize AE Bone Collections**. On a
   clean model, run Preflight → Build AE Controls; this organizes automatically.
4. Confirm that only FK controls are visible by default and that clicking
   auxiliary / original-skeleton toggles exposes the correct native bones.
5. Check source pose and weighted meshes, including outlines, before/after
   toggles. Rotate `SR_CTRL_AE_UpperArm.L` a small amount, **not** the original
   `Bip001_L_ForeTwist` bone. Use **Restore Calibrated Pose** afterward.
6. Verify Audit still returns COMPLETE. Remove the AE controls only after
   restoring calibration; compare all original bone memberships with a
   pre-build baseline, especially any existing multi-collection memberships.

**E1 tests use fake Blender RNA and cannot certify viewport display or
skinning in Blender 5.1.1.** The user-facing SaberRig version stays 1.0.1.

## AE Biped — Control Foundation, imported-pose calibration (Wulfa E1 candidate)

**Wulfa imported-pose fix (November 2026):** The E2 attempt exposed a
legitimate non-identity native pose in `Sabershadertest(2).blend`, NOT a
missing armature role. The original preflight stopped at `Bip001_Pelvis`:
its saved local translation is about `-0.0005492`, above the former 0.0001
identity threshold. Of the 23 anatomical roles, 20 have non-identity pose
bases above that threshold, including much larger shoulder/upper-arm
rotations. **Do not press Alt+G/Alt+R globally or change the original rig's
rest pose to make the earlier preflight pass.**

The new preflight accepts finite imported pose matrices when no source
constraints, armature Action/NLA/drivers or ownership conflicts exist. Build
calibrates all 25 **new** FK controls to the source's current evaluated pose,
using `Bone.convert_local_to_pose(..., invert=True)` and the exact new control
parent hierarchy before installing the 46 Copy Transforms constraints. It
then verifies control/source evaluated matrices against the recorded baseline;
if they differ beyond 0.0001, build aborts and attempts rollback. The original
23 source `matrix_basis` transforms are not overwritten. The JSON manifest
records native source pose/basis and all calibrated FK control bases.

Because identity is no longer the animator's initial control state, the AE tab
now provides **Restore Calibrated Pose**; use this after test posing and before
**Remove AE Controls**. Remove rejects modified source bases or controls that
differ from their saved calibration; it must never silently erase animation.
Legacy AE manifests without calibration retain the original identity-based
removal guard. These are new E1 behaviors: evaluation order, correct
`COPY_TRANSFORMS` behaviour and actual mesh deformation are **not yet
validated in Blender 5.1.1**. Always use a disposable copy of the `.blend`.

**Build on a duplicated `.blend` only. This new build has not been run in an
actual Blender 5.1.1 session.** The implementation is based on the Wulfa
`Root` armature topology audited in Blender: 331 original bones; 23 canonical
Biped roles with direct parents; 16 named twist bones; 30 correctives; 55 bound
meshes (including 7 SaberShader outline meshes). Zero native pose constraints
and no armature Action were reported in that input file.

The Endfield Biped tab now offers **Preflight / Build AE Controls / Audit /
Remove AE Controls**. The top SaberRig panel also routes Biped to the
dedicated workflow, not generic Prepare. The existing Endfield Segmented
profile is unchanged. The old `saberrig_prepared` property is *not* treated
as proof that the dedicated AE layer is installed.

- Builds **25 non-deforming FK controls**: Master, Root, COG, pelvis, two
  lower/upper spine bones, chest, neck, head, and both arms/legs through the
  hands and toes. Root/COG, spine, neck, head, clavicles, arms, hands, thighs,
  calves, feet and toes can be posed directly in the new FK hierarchy.
- Adds **23 parentless, non-deforming mechanism bones**, each copying its
  associated control in pose space. Each original anatomical source bone
  copies its matched mechanism in pose space (46 named `COPY_TRANSFORMS`
  constraints total). All new data uses `SR_CTRL_AE_`, `SR_MCH_AE_` and
  `SR_AE_BIPED_` identifiers and **two separate AE bone collections**.
- Does **not** reparent, rename, rest-pose edit, or change the `use_deform`
  flags, vertex groups or weights of the **331 source bones**. The 16 twist,
  30 directional corrective, face, hair, hat, shawl, skirt, cape and accessory
  bones are left untouched and continue inheriting their original parents.
  Their native game-time corrective formulas are not recreated.
- A strict **read-only preflight** requires a local non-overridden armature,
  all 23 original roles with the audited direct parents, finite imported pose,
  no existing constraints on the 23 sources, and no current armature Action,
  NLA tracks or drivers. Any existing generated SaberRig rig or conflicting
  AE names/collections blocks the build. If these conditions fail, the
  operator reports an error rather than attempting to reconfigure the model.
- Build snapshots the original rest/topology, imported pose bases and evaluated
  core poses, calibrates the new controls, and checks **imported-pose delta
  <= 1e-4** and source rest preservation before storing its JSON manifest. It attempts to
  remove every generated element on failure, including Edit Bones created
  before returning to Object Mode. **This E1 rollback is not a guarantee
  against a Blender native crash or unrecoverable Edit Mode error.**
- **Remove AE Controls** requires a complete verified manifest, original
  calibrated control/source bases and no Action/NLA/drivers. It removes only the named AE source
  constraints, mechanisms, controls, collections and manifest. Never use
  generic `Remove SaberRig Setup` or `Bake + Remove` for AE Biped; those
  paths are explicitly blocked while the AE layer is installed.
- No IK, automatic twist distribution, directional correctives, finger
  controllers, facial controls or secondary simulation are installed in
  this initial foundation. Generic build and production bake are locked
  while the AE foundation exists; they are not silently combined.

### Wulfa E2 acceptance checklist (Blender 5.1.1)

1. **Save As a new disposable copy** of the Wulfa scene before using Build.
   Select the `Root` armature, **leave Wulfa's imported pose as saved**,
   and run the external
   read-only `SaberRig_AE_Biped_Wulfa_E2_Probe.py` once to capture baseline.
2. Open **N-panel → SaberRig → Arknights: Endfield**, click **Preflight**,
   then **Build AE Controls**. A successful build should increase the native
   **331 bones to 379**, adding 25 `SR_CTRL_AE_` and 23 `SR_MCH_AE_` bones.
   If the operator fails, do not continue building; retain the duplicate
   and report the Blender console error.
3. Run the E2 probe again: all original rest matrices/parents/deform flags,
   armature modifiers, 55 bound meshes and vertex-group names must match the
   baseline; 46 AE constraints must point to the corresponding controls.
4. Check original imported pose visually, especially shoulders, face, correctives,
   torso, twists, hair, skirt and each visible LOD0 body/cloth mesh. Toggle
   *In Front* for the armature in Viewport Display if controls are hard to see.
5. Pose **one FK control at a time** (moderate +/- rotations), test Master,
   COG, pelvis, spine, head, arms and legs, and inspect deformation of Wulfa
   and any SaberShader outlines. This **is a real Blender E2 observation**, not
   something the offline test harness proves. Do not keyframe yet.
6. Use **Restore Calibrated Pose** (not Alt+R/Alt+G) to return all 25 AE
   controls to the saved reference. Click **Remove AE Controls**. Run the E2
   probe a third time; it should report 331 native bones, zero AE controls,
   zero AE mechanism bones, and unchanged native/mesh signatures.
7. Test an intentional preflight rejection on another duplicate (e.g.
   existing Action, a linked armature or non-finite source channels);
   no data should be added.

**E1 scope:** the offline harness uses a Wulfa-derived fake armature and checks
Python wiring, errors, rollback and exact rest snapshots. It **does not
validate Blender depsgraph ordering, `COPY_TRANSFORMS` evaluation, skin
appearance, real undo/redo or native crashes**. Results require the E2 probe,
console output and screenshots from actual Blender. Existing Fix3.2 Wiggle
render-sync limitations and Fix2 recovery-copy limits remain unresolved.

## Safety & Actions Fix1 (E1 candidate)

This candidate keeps the public add-on version at **1.0.1** while improving
registration rollback and Action Slot awareness. It has not been validated in a
Blender 5.1.1 session yet; keep a separate backup of the current installation
and test on duplicate `.blend` files.

- Registration records classes, the Scene property, the optional icon, and the
  frame-change handler so partial registration can be rolled back.
- Layered Actions are read through the armature's assigned Action Slot, not
  through a global collection of F-Curves. When a layered Action lacks a valid
  slot, animation-sensitive operations stop instead of assuming it is empty.
- Secondary-motion determinism remains outside this fix; the runtime still
  depends on the sequence in which frames are evaluated.

## Safety & Actions Fix1.1 — preflight and bake recovery (E1 candidate)

This incremental correction keeps the public version at **1.0.1** and does not
change the IK/FK or secondary-motion solvers. It has **not** been executed in
Blender yet. Save a duplicate of each `.blend` before trying it.

- Wiggle validates its Action Slot, candidate bones, chain metadata, and
  generated bone name collisions **before** deleting the previous setup.
- Full rig removal checks finger animation curves before resetting Wiggle
  runtime state or clearing its cached data.
- Failed NLA baking restores the original Action and Action Slot (if present),
  restores bake metadata, and removes newly created Actions **only when unused**.
  It reports an incomplete recovery rather than deleting Actions still in use.
- For Blender 5.1+, NLA bake requires `use_current_action=True` so it cannot
  silently fall back to creating an untracked Action.
- Registration cleanup accepts a frame-change handler that was already removed.
- Animation Space autokey reports failures rather than silently discarding them.

**Remaining limitations:** Blender's NLA bake, real Action Slots, and all model
profiles require live E2 validation. Rebuilding Wiggle is not yet fully
transactional after the preflight phase: a failure while creating bones or
constraints may still leave partial setup data. Secondary-motion determinism
remains a separate engineering task.

## Safety & Actions Fix1.2 — installation and staged Bake + Remove

- The **installable ZIP contains one top-level `saberrig/` folder**. License,
  notices, developer notes and the README are installed within this folder,
  instead of being scattered into the global Blender add-ons directory.
- **Bake + Remove performs a read-only Action Slot/linked-data preflight before
  creating a new Action.** It also retains the existing rig QA preflight.
- **This command is not a fully atomic two-phase transaction.** Blender's bone
  and constraint teardown can still fail after a successful bake. On such an
  error SaberRig reports that the baked Action remains, warns that removal may
  be partial, and returns `FINISHED` to retain an operator-level Undo boundary.
  This status **does not mean export succeeded**. Use Undo (if available) or
  reopen a saved duplicate; do not retry deletion on an incomplete rig.
- Errors during the final export metadata/QA refresh are reported separately
  from bake and teardown. Check the rig and report before exporting.
- The Python SPDX headers remain unchanged (`GPL-2.0-or-later`); the included
  `LICENSE` text is GPLv3. The rights holder should reconcile these notices
  before a public release. This fix does not alter licensing terms.

**E1 only:** Undo integration, operator return behavior, NLA Bake and destructive
rig teardown require verification in Blender 5.1.1 using disposable `.blend`
files. An E1 test cannot prove that the undo stack will recover every edit.

## Safety & Actions Fix1.3 — Edit Mode recovery and override preflight

- Bone removal now attempts to restore Object Mode in a `finally` block, even
  when editing a bone raises an exception. This reduces the chance of leaving
  an armature in Edit Mode after a partial teardown; it **does not restore any
  bones or constraints already removed**. If Blender cannot switch modes, the
  error is surfaced and the scene must be recovered from Undo or a backup.
- Bake + Remove explicitly rejects linked armatures **and** library overrides
  (object or armature data) before baking. Overrides may have restricted edits,
  so this destructive workflow is conservatively unsupported until tested.
- Bake + Remove may return `FINISHED` with a `WARNING` after a successful bake
  but failed teardown. **Automation must not treat `FINISHED` alone as proof of
  export readiness**. Inspect the operator report and rig state; after a
  warning, use Undo or reopen a backup before any retry or export.
- Licensing is unchanged: source SPDX headers say `GPL-2.0-or-later`, while
  the bundled `LICENSE` contains GPLv3 text. The rights holder must reconcile
  them before public distribution.

**E1 candidate only.** Confirm mode recovery, library overrides and Undo
behaviour in Blender 5.1.1 on disposable scenes before production use.

## Safety & Actions Fix1.4 — teardown preflight and error preservation

- **Remove SaberRig Setup**, **Remove Secondary Motion**, and both secondary-motion
  build paths now reject linked armatures and library overrides (object or
  armature data) before starting destructive changes. This is conservative:
  even editable library overrides are unsupported for these operations.
- Blender 5.1's documented `ID.override_library` property is checked on both
  datablocks. An unconfirmed `is_library_override` attribute is not required.
- Both edit-bone deletion helpers try to leave Edit Mode on failure. If that
  restoration also fails, the original error remains primary and the mode
  error is attached as an exception note when supported. A successful mode
  switch does not restore removed bones.
- Bake + Remove remains a staged, non-atomic operation. Its `FINISHED` status
  with a warning is **not** proof of export readiness.
- License metadata has not been changed. The mismatch between SPDX source
  headers and the bundled GPLv3 license text still requires a decision by the
  rights holder before public distribution.

**E1 candidate:** Test the three guarded workflows, Edit Mode recovery, and
Undo on disposable Blender 5.1.1 scenes before replacing a known-good build.


### Safety & Actions Fix1.5 — Preparation preflight (E1 candidate)

The shared `_armature_is_editable` check now rejects `override_library` on either the armature object or its datablock, as well as linked data. Both the generic `Prepare SaberRig` foundation and the one-click `FGO Prepare` run an explicit, read-only local-ownership preflight **before** creating collections, widgets, FGO reports, bones, or constraints. For linked/overridden rigs, use an independent, editable local copy. No automatic localization is performed.

These guards do **not** make the general or FGO preparation pipeline transactional after it begins. Individual FGO tools (preview, bridge, cleanup, etc.) require a separate complete entrypoint audit; this revision does not claim to protect every such path. The `FINISHED`/`WARNING` caveat for Bake + Remove, wiggle rebuild limits, and the pending SPDX/Licence reconciliation remain unchanged.


## Bake Integrity Fix2 — recoverable Bake + Remove (E1 candidate)

**Bake + Remove now requires a saved `.blend`**. Before calling NLA Bake, it
uses Blender's `save_as_mainfile(copy=True)` to write a uniquely named recovery
copy **beside the source `.blend`** (`*_SaberRig_before_BakeRemove_<random>.blend`).
If saving fails, if the file cannot be verified as a Blender file, or if the
original project was never saved, the operator **cancels before baking or
removing any rig data**. A successful run leaves the recovery copy in place;
remove it manually only after inspecting the final export. This can consume
substantial disk space, and external/unpacked resources may still need to be
available when reopening the copy. The original working filepath is expected
to remain active; verify this in Blender E2.

The backup is a **recovery checkpoint, not an atomic undo transaction**. If
Blender crashes or teardown fails after removing bones or constraints, do not
retry operations on the damaged rig. Reopen the recovery `.blend` (or use Undo
only after verifying it actually restored the scene). The backup captures the
scene **before the bake**, not the baked result; retain the generated Action
separately if needed.

The armature records machine-readable status after the bake begins:

- `saberrig_export_status = READY`: teardown, Action/slot provenance and QA
  checks succeeded; `saberrig_export_ready = True`.
- `FAILED_TEARDOWN`: bake succeeded but rig removal failed; the rig may be
  partial, and `saberrig_export_ready = False`.
- `FAILED_POSTCHECK`: removal finished but residue, assigned Action, slot or
  downstream QA could not be verified; **not export-ready**.
- `TEARDOWN_IN_PROGRESS`: a recovery state set after the bake and before
  destructive removal; treat it as **not export-ready**.

`FINISHED` with `WARNING` is still used to preserve Blender's operator Undo
boundary on partial changes. **Scripts must check `saberrig_export_ready` and
`saberrig_export_status`, not just the return value.** The recovery filename
is stored in `saberrig_export_recovery_file` when recording succeeds.

The other **Bake to Source** operator does not automatically save a `.blend`
recovery copy because it does not remove bones or constraints; its pre-existing
Action/slot rollback is unchanged. This revision does not make Wiggle rebuilding
or other rig removal operators transactional. Only test Fix2 on disposable
scenes until Blender 5.1.1 E2 and per-profile E3 pass.

Licensing notices remain unchanged. The discrepancy between
`GPL-2.0-or-later` SPDX headers and the bundled GPLv3 text requires a separate
rights-holder decision before a public release.


## Secondary Motion Fix3 — Handler and temporal stability (E1 candidate)

This candidate builds on **Bake Integrity Fix2** without changing the public
version (`1.0.1`), the spring profiles, the rig's generated bone names, or the
Bake + Remove safety checkpoint. It has **not** been validated in Blender
5.1.1; test on a separate `.blend` before using it in production.

- The `frame_change_post` handler now visits **only the armatures in the
  callback's scene**, rather than every armature in the entire `.blend`.
- Runtime spring, bone-list and collider caches are keyed by the armature's
  runtime RNA pointer, not its editable name. Renaming an armature therefore
  does not silently fork its spring history; this cache is **not persisted**.
- Multiple evaluations of the **same frame** do not advance velocity again.
  A backwards seek, a scene switch, or a forward jump of more than four frames
  resets Wiggle to its neutral state, with no implicit stale-state step.
- Forward gaps of two through four frames use bounded, fixed one-frame spring
  substeps. These steps use the **destination frame's** pose and collisions;
  they are **not equivalent** to playing all intermediate animated poses.
- The handler refreshes the active View Layer **only after pose data changes**
  and only when the active context belongs to the handler's scene. It avoids
  forcing a View Layer evaluation while a render job is reported as active.
  A reentrancy guard prevents nested handler execution.
- The generated-bone cache now detects missing cached bone names and rebuilds
  when a user renames a secondary MCH bone.

**Important limitations:** This is still a **history-dependent preview
solver**, not a deterministic random-access physics bake. The same destination
frame reached sequentially and by a large seek can have different Wiggle
poses. Scene/render synchronization, collision behavior, real playback and
frame-by-frame output must be measured in Blender E2. Blender officially
warns that edits made from frame handlers can race viewport updates during
rendering: use **Render → Lock Interface** when rendering scenes with Wiggle
active, and validate the output before exporting. A conditional View Layer
refresh is a performance and reentrancy improvement, not a guarantee of
thread safety or render fidelity.

Wiggle setup rebuilding remains non-atomic **after preflight**. Fix3 does not
make Bake + Remove or bone teardown atomic either; Fix2 recovery copies and
export-ready checks remain mandatory. The GPL-2.0-or-later / bundled GPLv3
notice discrepancy remains unchanged pending the rights-holder decision.

### Secondary Motion Fix3.1 — Cache lifecycle and render qualification (E1)

- The Fix3 spring preview is unchanged. It still uses `frame_change_post` and
  deliberately avoids forcing `view_layer.update()` during an active render.
  **Render timing and Copy Rotation evaluation may lag by a frame or fail to
  reflect Wiggle. This has not been resolved or validated in Blender.** Test
  F12 and an animation render against the viewport on disposable scenes, with
  Render → Lock Interface enabled, before production use. Do not assume that
  Lock Interface proves correctness: it mitigates concurrent UI risks.
- A persistent callback now clears the transient spring, MCH-list and collider
  caches after **file load, Undo and Redo**. These caches are never saved in
  the `.blend`. This reduces stale `as_pointer()` reuse across those events,
  but a deleted armature without Undo can leave a cache entry until the next
  lifecycle event; cache garbage collection is not yet exhaustive.
- Build operators that reject linked/overridden armatures now describe both
  causes instead of displaying only `linked/read-only`.
- Fix2's required backup files remain intentionally **manual to manage**. Do
  not delete recovery `.blend` files automatically until their contents have
  been verified. Check available disk space before repeated Bake + Remove.
- The 2–4 frame integration still samples the destination pose, so short seeks
  can differ from sequential playback. Same-frame idempotence is not path-
  independent determinism. Full solver, IK/FK and Action Slot behavior is
  unchanged.
- **E1 only.** Confirm in Blender 5.1.1: `load_post`, Undo/Redo, render with
  Wiggle, long/backward scrubbing, and the `save_as_mainfile(copy=True)`
  checkpoint remaining separate from the active original file. Consult the
  bundled QA guide. GPL headers and license text are unchanged.


### Secondary Motion Fix3.2 — Handler callback signature (E1)

- The runtime-cache invalidation callback now uses `(*_args)` instead of
  `(_event=None)` to tolerate optional/future positional arguments. Blender
  5.1 API documentation specifies one argument for all three callbacks:
  `load_post` receives the file path, while `undo_post` and `redo_post`
  receive the scene. The Blender 5.0 documentation explicitly describes
  the `load_post` argument, but leaves the Undo/Redo arguments unspecified.
  The earlier `(_event=None)` signature was already compatible with the
  documented Blender 5.1 contract. Accepting `*_args` is a defensive
  adjustment, not a fix for a confirmed Blender runtime bug.
- All cache-clearing logic, handler registration and rollback, physics and
  Bake + Remove behavior are unchanged. The fix **does not** resolve Wiggle
  render parity, path-independent determinism or non-atomic teardown.
- Before production, validate Undo/Redo, load handlers, F12, animation
  render and Fix2 recovery in Blender 5.1.1 using disposable `.blend` files.
  The SPDX/license discrepancy remains unchanged pending author review.

## AE Biped experimental IK, E1.4 (left arm only)

This candidate keeps the 25 existing FK controls intact. In a separate `.blend`
copy, select `Root` and use **N → SaberRig → Arknights: Endfield → Add Left Arm IK**.
The new IK solver is initially **inactive** (`FK` mode); it adds two animator
controls and five non-deforming mechanisms, organized into two new IK collections.
It also creates a third visibility collection named `SaberRig AE Left Arm FK`
for the three existing left-arm FK controls. Their previous memberships are
saved and restored upon successful IK removal. In FK mode, only the left FK
controls are visible; in IK mode, only left IK controls are visible.
All other FK controls remain in their pre-existing collection.
The solver uses shoulder→elbow and elbow→wrist *joint-head* distances from the
native rig, with a connected 2-bone chain and a calibrated pole plane.
When the elbow is near-straight, the anatomical rest hinge is transported
with the **evaluated native upper-arm** rotation (`Bip001_L_UpperArm`), not
with the potentially stale FK upper-arm control. The measured elbow offset
uses a reach-normalized criterion. The pole's EDIT rest head is placed at its
Master-calibrated initial location instead of using an arbitrary world -Z
position (Alt+G tests still require Blender E2 when the Master is posed).

- Click **Snap IK** to align the IK hand/pole and drive offsets to the currently
  evaluated FK arm and make IK active. Move `SR_CTRL_AE_IK_Hand.L` and
  `SR_CTRL_AE_IK_ElbowPole.L` only after a successful snap.
- Click **Snap FK** to transfer the IK result to FK controls and resume normal
  FK operation. A position error relative to anatomical arm reach, plus
  separate angular and relative scale guards, cancels a jump and restores
  the preceding mode and visibility.
- **Remove Left Arm IK** is only allowed while in FK mode. **Remove AE Controls**
  and the global FK baseline reset are disabled until this extension is removed.
- Save before testing; do not use this E1 pilot on a file containing Actions,
  NLA tracks or drivers. Do not edit IK generated bone rest geometry.
- If Blender reports an incomplete rollback or corrupted IK audit, **reopen
  the independent saved `.blend`** instead of retrying Build or Remove.
- Open `saberrig/diagnostics/SaberRig_AE_IK_Left_E2_ReadOnly_Probe.py`
  from **this installable add-on ZIP** in Blender's Scripting editor to export
  the current IK state. An independent copy is included at the root of the
  **separately downloadable E1.4 QA Kit ZIP**, not in this add-on's root.
  The E1.4 probe reports pole-to-elbow angle,
  `DRIVE_*`/MCH-to-native matrix deltas, and rest-relative native-vs-FK
  upper-arm rotation difference. Near-straight pole angle is flagged as
  unreliable. This probe does not change scene data.

**Not production verified:** Blender 5.1.1 numerical IK evaluation, deformation
of twist/corrective bones, cloth, and outline must be checked in real Blender.
Right arm and both legs were not included in the historical E1.4 left-arm pilot; see the Full FK/IK E1 section below.
Switching with Actions/NLA/drivers, per-frame baking, animation keyframing,
IK space switching, and smooth continuous blend are not supported yet.
**Reset Elbow Pole (Current Pose)** repositions the pole using the current
elbow plane, or the evaluated native upper-arm-transported anatomical rest
hinge when near straight. Unlike Alt+G, it is not tied to the build-time arm pose. It does
not magically fix a bend that is already pointed in a wrong IK direction;
Snap FK, correct the FK arm pose, and Snap IK for anatomical recentering.
Reset is blocked when Actions/NLA/drivers exist and rolls back on error.

The pole direction fallback is now evaluated ONLY for a nearly straight
POSE, so a meaningful bent elbow no longer requires the rest elbow to exceed
the 0.57-degree hinge threshold. The validation of nearly straight rest
anatomy still applies to the fallback branch.

If an older E1 IK pilot is already installed, remove it using the matching
old add-on while in FK mode before trying this E1.4 build. Never rebuild
on top of an existing IK pilot. Existing E1.1-built IK bones retain a
compatible manifest version (2) for this E1.4 maintenance update; audit in a
saved copy before operating on an existing pilot.

### E1.3 focused correction

`Reset Elbow Pole (Current Pose)` refreshes dependency-graph evaluation before
using the actual constrained native upper-arm rotation for near-straight
pole direction. The pole is not based on the inactive FK control in IK mode.
The operator remains subject to the existing snap and rollback guards.
This has only static regression coverage; test a fully extended IK arm with
the hand target at and just beyond maximum reach in Blender 5.1.1.

### E1.4 integration and removal-safety clarification

This is a **maintenance pass**, not a new IK solver. The Endfield sidebar's
left-arm IK label now reads E1.4. The main SaberRig panel performs one
`ae_biped.audit` per draw instead of two; the Endfield subpanel still runs its
own integrity audit. There is **no cross-draw cache**, avoiding stale status
when users alter constraints or bone collections. The generic bake function's
actual docstring has been restored without changing its AE guard.

`Remove Left Arm IK` has an extra read-only preflight for original FK collection
restoration. If removal fails after a destructive change, the error explicitly
reports **no automatic rollback** and instructs reopening the independently
saved `.blend`. Blender's `UNDO` flag is not claimed as a crash-proof or
transactional recovery mechanism. The operator remains experimental.

The pole-angle sweep, near-singular IK behaviour, twist/corrective deformation,
and viewport UI performance require native Blender 5.1.1 E2 measurements.
Changing the arm's direction, reaching exactly the limb limit, and moving the
hand target outside reach are mandatory tests. The four-limb rollout is implemented in the new E1 extension (see below); Actions,
keyframe-aware snapping, baking and space-switching remain outside scope.


## AE Biped — Full FK/IK Integration E1 (experimental)

This add-on extends the **already working left-arm E1.4 IK unchanged** with
three separately installable IK chains: right arm, left leg and right leg.
Each limb gets an independently calibrated goal, elbow/knee pole, two joint-head
length solver bones, driver bones and an FK/IK snap/visibility switch.
The right arm uses mirrored native joint positions and anatomical rest hinge;
the knee poles likewise come from their own native rest anatomy. No world-axis
hardcoding, stretch, new native bone parenting, or modifications of vertex
weights are introduced. `engine.py` and other profile solvers are preserved.

**Leg toe preservation:** unlike the arm chains, the leg outputs also include
`Toe.L` and `Toe.R`. A non-deforming `DriveToe` is parented to each IK foot drive
and calibrated to the native toe during FK→IK snap; the toe then follows the IK
foot instead of being left behind by the inactive FK foot controller. This is
**new behavior** and must be validated in Blender. Toe controls are hidden in
leg IK mode and reenabled by Snap FK. Fine independent toe-roll IK animation
has not been added.

Starting from an existing 379-bone AE FK rig, installing all four limbs yields
**409 bones** (379 + 7 left arm + 7 right arm + 8 left leg + 8 right leg).
If the left IK E1.4 pilot is already installed (386 bones), install ONLY the
other three limbs; do not rebuild the left arm. Each extension is optional,
starts in FK, audits the prior rig before writing and has its own Remove.
In a fresh test copy, build FK, then add IK one limb at a time. Use **Snap IK**
to enter IK and **Snap FK** to return. Remove each in FK before removing AE
Foundation. All snap/reset/remove paths still forbid Actions/NLA/drivers.
Removal is not fully transactional if interrupted after bone deletion:
**reopen the saved .blend instead of retrying a broken state.**

### Mandatory native E2 tests (Blender 5.1.1)

1. In a disposable copy of the verified E1.4 Wulfa file, add Right Arm IK;
   compare both directions of elbow bending and full reach (90/100/105%).
2. Add Left Leg IK and verify knee pole points toward anatomical knee flexion,
   90/100/105% reach, foot orientation, **toe stays with foot** and body/clothes.
3. Add Right Leg IK; verify mirrored knee bend, twist, bilateral squats and
   independent switching of all four limbs.
4. Snapshot before/after each build and snap with
   `saberrig/diagnostics/SaberRig_AE_Full_IK_E2_ReadOnly_Probe.py`.
5. Switch each limb back to FK, remove right/left leg/right arm one by one,
   then remove left pilot only if desired. Confirm exactly 379 AE FK bones.

E1 represents **static QA + source review**, NOT native Blender verification
of new limbs. IK keyframes/baking, stretch and space switching remain out of scope.

Previous legacy install names (for audit compatibility only): `SaberRig_1_0_1_AE_Left_Arm_IK_Pilot_E1_3.zip`, E1.4.

## E2.4 — AE Leg IK Foot-Follow (experimental)

For Arknights: Endfield Biped, each leg's FK/IK box contains **Foot Follow ON**
(default when pressing **Snap IK**) and **Static Pole**. An optional no-deform,
translation-following knee guide is created on the first activation, including
for existing E2.3 left/right leg IK rigs. FK and the four original IK solvers
remain intact. Original scene links, Eye/Si attachments and FGO are unchanged.

Use a saved duplicate and test in Blender 5.1.1. The E2.4 follow guide is based
on the FGO knee-pole architecture but is **not yet E2-validated** for AE.
See `diagnostics/SaberRig_AE_Foot_Follow_E2_4_ReadOnly_Probe.py` and the E2.4
README in the separate QA Kit for tests and known limitations.
