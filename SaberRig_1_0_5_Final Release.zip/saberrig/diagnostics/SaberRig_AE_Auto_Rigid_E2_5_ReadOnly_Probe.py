# SPDX-License-Identifier: GPL-2.0-or-later
"""Read-only E2.5 attachment diagnostic; run inside Blender 5.1.1 Scripting.

Select the Endfield armature. Does not require installed SaberRig module.
Writes an external JSON report to the OS temporary directory only.
"""
import bpy
import json
import tempfile
from pathlib import Path
from datetime import datetime, timezone

PROFILE_BINDINGS = {
    'S_actor_jsspsi_iris_01_lod0': 'face_Head',
    'S_actor_jsspsi_cloth_06_lod0': 'Bip001',
    'S_actor_jsspsi_cloth_09_lod0': 'Bip001',
    'S_actor_jsspsi_vfxpart_01_lod0': 'Bip001',
    'S_actor_jsspsi_vfxpart_02_lod0': 'Bip001',
    'S_actor_jsspsi_vfxpart_05_lod0': 'Bip001',
    'S_actor_jsspsi_vfxpart_06_lod0': 'Bip001',
    'S_actor_jsspsi_vfxpart_07_lod0': 'Bip001',
}

def flatten(m):
    return [float(m[r][c]) for r in range(4) for c in range(4)]

def main():
    arm = bpy.context.active_object
    if arm is None or arm.type != 'ARMATURE':
        raise RuntimeError('Select the Endfield armature before running E2.5 probe')
    bpy.context.view_layer.update()
    scene=bpy.context.scene
    entries=[]
    for name, expected in PROFILE_BINDINGS.items():
        ob=bpy.data.objects.get(name)
        if ob is None or ob.parent != arm or ob.name not in scene.objects:
            continue
        entries.append({
            'name':ob.name, 'parent':ob.parent.name if ob.parent else None,
            'parent_type':ob.parent_type,'parent_bone':ob.parent_bone,
            'expected_target':expected,'matches_expected_target':ob.parent_type=='BONE' and ob.parent_bone==expected,
            'world_matrix':flatten(ob.matrix_world),
            'evaluated_world_matrix':flatten(ob.evaluated_get(bpy.context.evaluated_depsgraph_get()).matrix_world),
            'armature_modifier_count':sum(m.type=='ARMATURE' for m in ob.modifiers),
            'vertex_group_count':len(ob.vertex_groups),
            'constraints':[c.name for c in ob.constraints],
        })
    status = ('NO_VERIFIED_SIGNATURE' if not entries
              else 'COMPLETE_VERIFIED_SIGNATURE' if len(entries)==8
              else 'PARTIAL_SIGNATURE')
    payload={
        'title':'SaberRig AE E2.5 automatic rigid attachment verification',
        'utc':datetime.now(timezone.utc).isoformat(),
        'file':bpy.data.filepath, 'blender':bpy.app.version_string,
        'armature':arm.name,'signature_status':status,
        'ae_foundation_present':bool(arm.get('saberrig_ae_biped_foundation')),
        'legacy_attachment_manifest_present':bool(arm.get('saberrig_ae_si_rigid_attachment_pilot_v1')),
        'present_count':len(entries), 'expected_count':len(PROFILE_BINDINGS),
        'entries':entries,
    }
    raw=arm.get('saberrig_ae_biped_foundation')
    if raw:
        try:payload['auto_rigid_attachments']=json.loads(str(raw)).get('auto_rigid_attachments')
        except (ValueError,TypeError):payload['auto_rigid_attachments']='INVALID_AE_MANIFEST'
    path=Path(tempfile.gettempdir())/('SaberRig_AE_Auto_Rigid_E2_5_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')+'.json')
    path.write_text(json.dumps(payload,indent=2,ensure_ascii=False),encoding='utf-8')
    print('SABERRIG AE AUTO RIGID E2.5 READ ONLY:',str(path))
    print('Signature:',status,'| attached to targets:',sum(e['matches_expected_target'] for e in entries),'/',len(entries))
    return path

if __name__=='__main__':
    main()
