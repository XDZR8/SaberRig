# SPDX-License-Identifier: GPL-2.0-or-later
"""AE Leg IK Foot Follow E2.4 diagnostics for Blender 5.1.1.

READ ONLY with respect to the scene: writes only an external JSON to temp.
Run in Blender Scripting, with the AE armature selected (Pose/Object Mode).
Repeat at neutral, foot raised, foot out of reach, after returning to FK.
"""

import bpy
import json
import math
import os
import tempfile
from datetime import datetime, timezone
from mathutils import Vector

MANIFEST_KEY = 'saberrig_ae_biped_foundation'


def vec(v):
    return [round(float(x), 8) for x in v]


def diag(arm, side, data):
    limb_key = 'ik_leg_' + side.lower()
    leg = data.get(limb_key)
    result = {'side':side, 'installed': isinstance(leg,dict)}
    if not isinstance(leg,dict):
        return result
    foot = 'SR_CTRL_AE_IK_Foot.'+side
    manual = 'SR_CTRL_AE_IK_KneePole.'+side
    guide = 'SR_MCH_AE_IK_FootFollowPole.'+side
    upper = 'SR_MCH_AE_IK_Thigh.'+side
    lower = 'SR_MCH_AE_IK_Calf.'+side
    solver_name = 'SR_AE_IK_L'+side+'_SOLVER'
    pb = arm.pose.bones
    missing = [name for name in (foot,manual,upper,lower) if pb.get(name) is None]
    result.update({'mode':leg.get('mode'), 'follow_metadata':leg.get('foot_follow'),
                   'missing_bones':missing})
    if missing:
        return result
    ik = pb[lower].constraints.get(solver_name)
    result['solver'] = (dict(type=ik.type, subtarget=ik.subtarget,
                             pole_subtarget=ik.pole_subtarget,
                             pole_angle_deg=round(math.degrees(ik.pole_angle),5)) if ik else None)
    if ik is None:
        return result
    native = ['Bip001_'+side+'_Thigh','Bip001_'+side+'_Calf','Bip001_'+side+'_Foot']
    for name in native:
        if pb.get(name) is None:
            result['missing_native'] = name
            return result
    hip, knee, ankle = (pb[name].head.copy() for name in native)
    target = pb[foot]
    result['foot_target_armature_xyz'] = vec(target.head)
    result['original_pole_armature_xyz'] = vec(pb[manual].head)
    result['native_joint_heads'] = {'hip':vec(hip),'knee':vec(knee),'ankle':vec(ankle)}
    result['native_knee_reach'] = float((ankle-hip).length)
    follow_pb = pb.get(guide)
    if follow_pb is not None:
        g = follow_pb.bone
        result['guide'] = {
            'position':vec(follow_pb.head), 'foot_to_guide':vec(follow_pb.head-target.head),
            'parent':g.parent.name if g.parent else None,
            'inherit_rotation':bool(g.use_inherit_rotation),
            'inherit_scale':str(g.inherit_scale), 'deform':bool(g.use_deform),
            'collections':[c.name for c in g.collections],
        }
    else:
        result['guide'] = None
    pole_pb = pb.get(ik.pole_subtarget)
    if pole_pb is None:
        result['warning'] = 'MISSING_ACTIVE_SOLVER_POLE'
        return result
    v=ankle-hip
    if v.length<=1e-9:
        result['warning']='COLLAPSED_HIP_TO_ANKLE'
        return result
    axis=v.normalized()
    bend=(knee-hip)-axis*(knee-hip).dot(axis)
    active=(pole_pb.head-hip)-axis*(pole_pb.head-hip).dot(axis)
    result['knee_plane'] = {
        'native_bend_offset':round(bend.length,8),
        'active_pole_offset':round(active.length,8),
        'bend_to_pole_angle_deg': (round(math.degrees(bend.angle(active)),4)
                                   if bend.length>1e-4 and active.length>1e-5 else None),
        'near_straight_noise_warning': bend.length<=1e-4,
    }
    return result


def main():
    obj=bpy.context.active_object
    if obj is not None and obj.type!='ARMATURE' and obj.parent and obj.parent.type=='ARMATURE':
        obj=obj.parent
    if obj is None or obj.type!='ARMATURE':
        raise RuntimeError('Select the AE armature in Blender before running E2.4 probe')
    raw=obj.get(MANIFEST_KEY)
    if not raw:
        raise RuntimeError('Selected armature has no SaberRig AE Biped manifest')
    data=json.loads(str(raw))
    result={
        'title':'SaberRig AE Foot Follow E2.4 native read-only pose diagnostic',
        'time_utc':datetime.now(timezone.utc).isoformat(),
        'blender_version':bpy.app.version_string,
        'blend':bpy.data.filepath,
        'armature':obj.name,
        'bone_count':len(obj.data.bones),
        'left':diag(obj,'L',data),
        'right':diag(obj,'R',data),
        'note':'Read only. Repeat on tested trajectories; one snapshot cannot prove the absence of pole flips.',
    }
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    path=os.path.join(tempfile.gettempdir(),'SaberRig_AE_FootFollow_E2_4_'+stamp+'.json')
    with open(path,'w',encoding='utf-8') as f:
        json.dump(result,f,ensure_ascii=False,indent=2)
    print('SABERRIG AE FOOT FOLLOW E2.4 READ ONLY:',path)
    for side in ('left','right'):
        d=result[side]
        print(side.upper(), 'mode:',d.get('mode'),
              'follow:',bool((d.get('follow_metadata') or {}).get('enabled')),
              'knee-plane:',d.get('knee_plane'))
    return path


if __name__=='__main__':
    main()
