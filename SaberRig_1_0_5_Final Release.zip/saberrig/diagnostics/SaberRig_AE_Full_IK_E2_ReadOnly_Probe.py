# SPDX-License-Identifier: GPL-2.0-or-later
"""READ ONLY multi-limb AE FK/IK diagnostic, Blender 5.1.1.

Run as a Text Editor script. Writes one JSON report to the OS temp directory;
does not change pose, constraints, collections, Actions, or scene data.
"""
import bpy
import json
import math
import os
import tempfile
from datetime import datetime, timezone

KEY = 'saberrig_ae_biped_foundation'
SPECS = {
    'ARM.L': ('ik_arm_l', ('Bip001_L_UpperArm', 'Bip001_L_Forearm', 'Bip001_L_Hand'),
              ('UpperArm.L', 'Forearm.L', 'Hand.L'),
              ('SR_MCH_AE_IK_DriveUpperArm.L', 'SR_MCH_AE_IK_DriveForearm.L', 'SR_MCH_AE_IK_DriveHand.L'),
              'SR_CTRL_AE_IK_Hand.L', 'SR_CTRL_AE_IK_ElbowPole.L', None),
    'ARM.R': ('ik_arm_r', ('Bip001_R_UpperArm', 'Bip001_R_Forearm', 'Bip001_R_Hand'),
              ('UpperArm.R', 'Forearm.R', 'Hand.R'),
              ('SR_MCH_AE_IK_DriveUpperArm.R', 'SR_MCH_AE_IK_DriveForearm.R', 'SR_MCH_AE_IK_DriveHand.R'),
              'SR_CTRL_AE_IK_Hand.R', 'SR_CTRL_AE_IK_ElbowPole.R', None),
    'LEG.L': ('ik_leg_l', ('Bip001_L_Thigh', 'Bip001_L_Calf', 'Bip001_L_Foot'),
              ('Thigh.L', 'Calf.L', 'Foot.L'),
              ('SR_MCH_AE_IK_DriveThigh.L', 'SR_MCH_AE_IK_DriveCalf.L', 'SR_MCH_AE_IK_DriveFoot.L'),
              'SR_CTRL_AE_IK_Foot.L', 'SR_CTRL_AE_IK_KneePole.L', ('Bip001_L_Toe0', 'Toe.L', 'SR_MCH_AE_IK_DriveToe.L')),
    'LEG.R': ('ik_leg_r', ('Bip001_R_Thigh', 'Bip001_R_Calf', 'Bip001_R_Foot'),
              ('Thigh.R', 'Calf.R', 'Foot.R'),
              ('SR_MCH_AE_IK_DriveThigh.R', 'SR_MCH_AE_IK_DriveCalf.R', 'SR_MCH_AE_IK_DriveFoot.R'),
              'SR_CTRL_AE_IK_Foot.R', 'SR_CTRL_AE_IK_KneePole.R', ('Bip001_R_Toe0', 'Toe.R', 'SR_MCH_AE_IK_DriveToe.R')),
}


def _vec(vec):
    return [float(x) for x in vec]


def _matrix(matrix):
    return [[float(matrix[i][j]) for j in range(4)] for i in range(4)]


def _delta(left, right):
    if left is None or right is None:
        return None
    la, lb = left.to_scale(), right.to_scale()
    return {'position': float((left.translation-right.translation).length),
            'rotation_deg': math.degrees(left.to_quaternion().rotation_difference(right.to_quaternion()).angle),
            'scale_relative': max(abs(a-b)/max(abs(b),1e-6) for a,b in zip(la,lb)),
            'matrix_max_abs': max(abs(left[i][j]-right[i][j]) for i in range(4) for j in range(4))}


def _find_arm():
    obj = bpy.context.object
    if obj and obj.type == 'ARMATURE' and obj.get(KEY):
        return obj
    candidates = [x for x in bpy.data.objects if x.type == 'ARMATURE' and x.get(KEY)]
    if len(candidates) != 1:
        raise RuntimeError('Select one AE armature. Candidates: ' + str(len(candidates)))
    return candidates[0]


def _limb_report(arm, ext, spec, key):
    ext_key, joint_names, labels, drives, effector, pole_name, toe = spec
    mode = ext.get('mode', 'NOT_INSTALLED')
    pb = arm.pose.bones
    report = {'key': ext_key, 'mode': mode, 'manifest_version': ext.get('version'),
              'pole_calibration_score': ext.get('pole_calibration_score'),
              'pole_angle': ext.get('pole_angle'), 'joints': {}, 'warnings': [],
              'geometry': None, 'pole_alignment': None, 'toe_follow': None}
    for source, label, drive in zip(joint_names, labels, drives):
        native, mch, driver, fk = (pb.get(source), pb.get('SR_MCH_AE_'+label),
                                    pb.get(drive), pb.get('SR_CTRL_AE_'+label))
        report['joints'][label] = {
            'source': source, 'drive': drive,
            'native_to_drive': _delta(native.matrix,driver.matrix) if native and driver else None,
            'native_to_mch': _delta(native.matrix,mch.matrix) if native and mch else None,
            'native_to_fk': _delta(native.matrix,fk.matrix) if native and fk else None,
            'source_matrix': _matrix(native.matrix) if native else None,
            'drive_matrix': _matrix(driver.matrix) if driver else None,
            'mch_constraints': [{'name': c.name, 'type':c.type,
                                 'influence':float(c.influence),
                                 'subtarget':getattr(c,'subtarget',None)}
                                for c in mch.constraints] if mch else None}
    if toe:
        source, label, drive = toe
        src, mch, drv = pb.get(source), pb.get('SR_MCH_AE_'+label), pb.get(drive)
        report['toe_follow'] = {
            'source':source, 'drive':drive,
            'native_to_drive':_delta(src.matrix,drv.matrix) if src and drv else None,
            'native_to_mch':_delta(src.matrix,mch.matrix) if src and mch else None,
            'drive_parent':drv.parent.name if drv and drv.parent else None,
            'source_matrix':_matrix(src.matrix) if src else None,
            'drive_matrix':_matrix(drv.matrix) if drv else None}
        if mode=='IK' and (drv is None or drv.parent is None):
            report['warnings'].append('MISSING_TOE_DRIVE_OR_PARENT')
    if any(pb.get(name) is None for name in joint_names):
        report['warnings'].append('NATIVE_CHAIN_INCOMPLETE')
        return report
    a,b,c=(pb[name].head.copy() for name in joint_names)
    axis=c-a
    lengths=((b-a).length,(c-b).length)
    if axis.length<1e-8 or min(lengths)<1e-8:
        report['warnings'].append('DEGENERATE_CHAIN')
        return report
    reach=sum(lengths)
    axis_dir=axis.normalized()
    offset=(b-a)-axis_dir*((b-a).dot(axis_dir))
    eff=pb.get(effector); pole=pb.get(pole_name)
    report['geometry'] = {
        'heads':[_vec(a),_vec(b),_vec(c)], 'lengths':list(lengths),
        'reach':reach,'reach_fraction':axis.length/reach,
        'bend_offset':offset.length, 'bend_offset_to_reach':offset.length/reach,
        'flex_angle_deg':math.degrees((b-a).angle(c-b)),
        'goal_distance':(eff.head-a).length if eff else None,
        'goal_distance_to_reach':(eff.head-a).length/reach if eff else None,
        'wrist_to_goal_distance':(eff.head-c).length if eff else None}
    if pole is not None:
        pole_delta=(pole.head-a)-axis_dir*((pole.head-a).dot(axis_dir))
        stable=(offset.length/reach > 0.02 and pole_delta.length/reach>0.02)
        report['pole_alignment']={
            'pole_head':_vec(pole.head), 'rest_head':_vec(pole.bone.head_local),
            'stable_measurement':bool(stable),
            'angle_pole_to_joint_deg':math.degrees(offset.angle(pole_delta))
                 if offset.length>1e-8 and pole_delta.length>1e-8 else None}
        if not stable:
            report['warnings'].append('NEAR_STRAIGHT_POLE_ANGLE_UNRELIABLE')
    else:
        report['warnings'].append('MISSING_POLE')
    if eff is None: report['warnings'].append('MISSING_EFFECTOR')
    return report


def main():
    arm=_find_arm()
    manifest=json.loads(str(arm.get(KEY,'{}')))
    ts=datetime.now(timezone.utc)
    result={'title':'SaberRig AE Full FK/IK E1 E2 READ ONLY',
            'time_utc':ts.isoformat(),'blender_version':bpy.app.version_string,
            'blend':bpy.data.filepath,'armature':arm.name,
            'bones':len(arm.data.bones), 'extensions':{},'collections':{},'animation':{},
            'warnings':[]}
    ad=arm.animation_data
    result['animation']={'action':ad.action.name if ad and ad.action else None,
                         'nla_tracks':len(ad.nla_tracks) if ad else 0,
                         'drivers':len(ad.drivers) if ad else 0}
    for limb,spec in SPECS.items():
        key=spec[0]
        ext=manifest.get(key)
        result['extensions'][limb]=(_limb_report(arm,ext,spec,key) if isinstance(ext,dict)
                                     else {'mode':'NOT_INSTALLED'})
    collections=set(manifest.get('collections',[]))
    for spec in SPECS.values():
        ext=manifest.get(spec[0])
        if isinstance(ext,dict):
            collections.update(ext.get('collections',[]))
    for colname in sorted(collections):
        col=arm.data.collections.get(colname)
        result['collections'][colname]={'exists':col is not None,
               'visible':bool(col.is_visible) if col else None,
               'members':len(col.bones) if col else None}
    p=os.path.join(tempfile.gettempdir(),'SaberRig_AE_Full_IK_E2_'+ts.strftime('%Y%m%dT%H%M%S_%fZ')+'.json')
    with open(p,'w',encoding='utf8') as f: json.dump(result,f,indent=2,ensure_ascii=False)
    print('SABERRIG AE FULL FK/IK E2:',p)
    print('Bones:',result['bones'])
    for limb,info in result['extensions'].items():
        print(limb, 'mode', info['mode'], 'pole', info.get('pole_alignment'), 'toe',info.get('toe_follow'))
    return p

main()
