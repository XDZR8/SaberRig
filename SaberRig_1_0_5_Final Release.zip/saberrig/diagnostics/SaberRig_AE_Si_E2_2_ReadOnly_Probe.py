# SaberRig AE E2.2 — Blender 5.1.1 read-only probe for native source skeleton.
# Executing this script does not change the scene. It writes one JSON to temp.
import bpy
import json
import math
import os
from datetime import datetime, timezone
from pathlib import Path
import tempfile

SOURCE = (
    'Bip001', 'Bip001_Pelvis', 'Bip001_Spine', 'Bip001_Spine1',
    'Bip001_Spine2', 'Bip001_Neck', 'Bip001_Head',
    'Bip001_L_Clavicle','Bip001_L_UpperArm','Bip001_L_Forearm','Bip001_L_Hand',
    'Bip001_R_Clavicle','Bip001_R_UpperArm','Bip001_R_Forearm','Bip001_R_Hand',
    'Bip001_L_Thigh','Bip001_L_Calf','Bip001_L_Foot','Bip001_L_Toe0',
    'Bip001_R_Thigh','Bip001_R_Calf','Bip001_R_Foot','Bip001_R_Toe0',
)

def matrix(m):
    return [float(m[i][j]) for i in range(4) for j in range(4)]

def vec(v):
    return [float(v[0]),float(v[1]),float(v[2])]

def root_chain(arm):
    result=[];bone=arm.data.bones.get('Bip001');seen=set()
    while bone is not None and bone.name not in seen and len(result)<8:
        result.append(bone.name)
        seen.add(bone.name);bone=bone.parent
    return result

def current_arm():
    ob=bpy.context.object
    if ob and ob.type=='ARMATURE' and ob.data.bones.get('Bip001'):
        return ob
    candidates=[o for o in bpy.context.scene.objects if o.type=='ARMATURE'
                and o.data.bones.get('Bip001')]
    if len(candidates)!=1:
        raise RuntimeError('Select the intended AE armature; candidates: '+
                           ', '.join(o.name for o in candidates))
    return candidates[0]

arm=current_arm();bpy.context.view_layer.update()
original={}
for bone in arm.data.bones:
    # Exclude SaberRig-generated helpers; retain every native bone, including wrappers.
    if bone.get('saberrig_generated', False) or bone.name.startswith(('SR_CTRL_AE_', 'SR_MCH_AE_')):
        continue
    pb=arm.pose.bones.get(bone.name)
    if pb is None:
        raise RuntimeError('Missing pose channel: '+bone.name)
    original[bone.name]={
        'parent':bone.parent.name if bone.parent else None,
        'head':vec(bone.head_local), 'tail':vec(bone.tail_local),
        'rest':matrix(bone.matrix_local), 'use_deform':bool(bone.use_deform),
        'pose':matrix(pb.matrix), 'basis':matrix(pb.matrix_basis),
        'constraints':[{'name':c.name,'type':c.type} for c in pb.constraints],
    }

ad=arm.animation_data
linked=[]
for obj in bpy.context.scene.objects:
    if obj.type!='MESH':continue
    mods=[m for m in obj.modifiers if m.type=='ARMATURE' and m.object==arm]
    if mods:
        linked.append({'name':obj.name, 'verts':len(obj.data.vertices),
                       'vertex_groups':len(obj.vertex_groups),'armature_modifiers':len(mods)})

payload={
    'title':'SaberRig AE E2.2 - native skeleton read-only',
    'timestamp_utc':datetime.now(timezone.utc).isoformat(),
    'blender_version':'.'.join(str(n) for n in bpy.app.version[:3]),
    'file_path':bpy.data.filepath,
    'armature':arm.name,'armature_data':arm.data.name,'mode':arm.mode,
    'object_matrix_world':matrix(arm.matrix_world),
    'root_chain':root_chain(arm),
    'bone_count_total':len(arm.data.bones),
    'original_bones_count':len(original),
    'roles_found':sum(n in original for n in SOURCE),
    'source_role_mappings':{n:original.get(n,{}).get('parent') for n in SOURCE},
    'native_bones':original,
    'mesh_bindings':linked,
    'animation':{'action':str(ad.action.name) if ad and ad.action else None,
                 'nla':len(ad.nla_tracks) if ad else 0,
                 'drivers':len(ad.drivers) if ad else 0},
    'manifest_present':bool(arm.get('saberrig_ae_biped_foundation')),
}
if not all(math.isfinite(x) for row in original.values()
           for x in row['rest']+row['pose']+row['basis']):
    raise RuntimeError('Non-finite native pose/rest matrix; no JSON written')
name='SaberRig_AE_Si_E2_2_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')+'.json'
path=Path(tempfile.gettempdir())/name
path.write_text(json.dumps(payload,indent=2,ensure_ascii=False),encoding='utf-8')
print('SABERRIG AE SI E2.2 READ ONLY:',str(path))
print('Native:',len(original),'Total:',len(arm.data.bones),
      'Roles:',payload['roles_found'],'Root chain:', ' -> '.join(payload['root_chain']))
