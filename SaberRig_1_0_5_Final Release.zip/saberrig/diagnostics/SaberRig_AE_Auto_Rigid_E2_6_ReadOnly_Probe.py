# SPDX-License-Identifier: GPL-2.0-or-later
"""Read-only E2.6 attachment/pose evidence for Blender 5.1.1.

Run in Scripting with the intended Endfield ARMATURE active. This script only
writes a JSON file in the OS temporary directory. Compare snapshots from a
neutral pose and from bent pelvis/spine poses to evaluate proposed VFX parents.
Bone-relative transforms are diagnostic, NOT proof of correct cloth behavior.
"""
import bpy
import json
import tempfile
from pathlib import Path
from datetime import datetime, timezone

AE_KEY = 'saberrig_ae_biped_foundation'
PILOT_KEY = 'saberrig_ae_si_rigid_attachment_pilot_v1'
EXPECTED = {
    'S_actor_jsspsi_iris_01_lod0': 'face_Head',
    'S_actor_jsspsi_cloth_06_lod0': 'Bip001',
    'S_actor_jsspsi_cloth_09_lod0': 'Bip001',
    'S_actor_jsspsi_vfxpart_01_lod0': 'Bip001',
    'S_actor_jsspsi_vfxpart_02_lod0': 'Bip001',
    'S_actor_jsspsi_vfxpart_05_lod0': 'Bip001',
    'S_actor_jsspsi_vfxpart_06_lod0': 'Bip001',
    'S_actor_jsspsi_vfxpart_07_lod0': 'Bip001',
}
REFERENCE_BONES = ('Bip001', 'Bip001_Pelvis', 'Bip001_Spine',
                   'Bip001_Spine1', 'Bip001_Spine2', 'Bip001_Head',
                   'face_Head', 'lod0')


def flat(mat):
    return [float(mat[i][j]) for i in range(4) for j in range(4)]


def main():
    arm = bpy.context.active_object
    if arm is None or arm.type != 'ARMATURE':
        raise RuntimeError('Select the intended AE armature before running probe')
    bpy.context.view_layer.update()
    graph = bpy.context.evaluated_depsgraph_get()
    eval_arm = arm.evaluated_get(graph)
    bones = {}
    for name in REFERENCE_BONES:
        pb = eval_arm.pose.bones.get(name)
        if pb is not None:
            bones[name] = eval_arm.matrix_world @ pb.matrix
    entries = []
    for name, intended in EXPECTED.items():
        obj = bpy.data.objects.get(name)
        if obj is None or obj.parent != arm or name not in bpy.context.scene.objects:
            entries.append({'name':name,'status':'MISSING_OR_DIFFERENT_PARENT'})
            continue
        obj_world = obj.evaluated_get(graph).matrix_world.copy()
        entries.append({
            'name':name,'status':'PRESENT','expected_target':intended,
            'parent_bone':obj.parent_bone,'parent_type':obj.parent_type,
            'matches_expected_parent':obj.parent_type=='BONE' and obj.parent_bone==intended,
            'world_matrix_evaluated':flat(obj_world),
            'relative_to_bones':{bn:flat(bmat.inverted_safe() @ obj_world)
                                 for bn,bmat in bones.items()},
        })
    raw=arm.get(AE_KEY)
    ae_manifest=None
    ae_error=None
    if raw:
        try:
            ae_manifest=json.loads(str(raw))
        except (TypeError,ValueError) as exc:
            ae_error=str(exc)
    metadata=(ae_manifest.get('auto_rigid_attachments')
              if isinstance(ae_manifest,dict) else None)
    out = {
        'title':'SaberRig AE rigid-attachment E2.6 read-only pose snapshot',
        'utc':datetime.now(timezone.utc).isoformat(),
        'blender':bpy.app.version_string,'blend_file':bpy.data.filepath,
        'armature':arm.name,'current_frame':bpy.context.scene.frame_current,
        'ae_manifest_present':bool(raw),'ae_manifest_parse_error':ae_error,
        'pilot_manifest_present':bool(arm.get(PILOT_KEY)),
        'auto_rigid_attachments':metadata,
        'owned_consistent': bool(metadata and arm.get(PILOT_KEY)),
        'bones_evaluated_world':{name:flat(matrix) for name,matrix in bones.items()},
        'entries':entries,
        'warning':('Relative transform constancy is not proof that Bip001 is the '
                   'correct anatomical parent for cloth or VFX. Inspect bending '
                   'of pelvis, spine, and raised arms in Blender viewport.'),
    }
    target=Path(tempfile.gettempdir())/('SaberRig_AE_E2_6_Attachments_'
       +datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')+'.json')
    target.write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8')
    print('SABERRIG AE AUTO RIGID E2.6 READ ONLY:',target)
    print('Owned:',out['owned_consistent'],'| parents match:',
          sum(e.get('matches_expected_parent',False) for e in entries),'/',len(EXPECTED))
    return target

if __name__=='__main__':
    main()
