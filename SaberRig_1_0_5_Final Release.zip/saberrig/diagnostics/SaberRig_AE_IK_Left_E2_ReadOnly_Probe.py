# SPDX-License-Identifier: GPL-2.0-or-later
"""SaberRig AE Left IK E1.3 E2 READ ONLY diagnostic for Blender 5.1.1.

Run from Scripting with the AE rig selected. No mutations of scene, meshes,
pose matrices, constraints, visibility, or animation data. Writes JSON to temp.
"""
import bpy
import json
import math
import os
import tempfile
from datetime import datetime, timezone

MANIFEST_KEY = 'saberrig_ae_biped_foundation'
LEFT_IK_KEY = 'ik_arm_l'
JOINTS = ('Bip001_L_UpperArm', 'Bip001_L_Forearm', 'Bip001_L_Hand')
LABELS = ('UpperArm.L', 'Forearm.L', 'Hand.L')
DRIVES = ('SR_MCH_AE_IK_DriveUpperArm.L',
          'SR_MCH_AE_IK_DriveForearm.L', 'SR_MCH_AE_IK_DriveHand.L')
POLE = 'SR_CTRL_AE_IK_ElbowPole.L'
IK_HAND = 'SR_CTRL_AE_IK_Hand.L'


def vec3(v):
    return [float(x) for x in v]


def matrix4(m):
    return [[float(m[i][j]) for j in range(4)] for i in range(4)]


def metrics(a, b):
    if a is None or b is None:
        return None
    scale_a, scale_b = a.to_scale(), b.to_scale()
    return {
        'matrix_max_abs_element': max(abs(a[i][j] - b[i][j])
                                      for i in range(4) for j in range(4)),
        'translation_distance': float((a.translation - b.translation).length),
        'rotation_angle_deg': math.degrees(
            a.to_quaternion().rotation_difference(b.to_quaternion()).angle),
        'max_relative_scale_delta': max(abs(x-y)/max(abs(y), 1e-6)
                                        for x,y in zip(scale_a,scale_b)),
    }


def find_rig():
    active = bpy.context.object
    if (active is not None and active.type == 'ARMATURE'
            and active.get(MANIFEST_KEY)):
        return active
    candidates = [o for o in bpy.data.objects if o.type == 'ARMATURE'
                  and o.get(MANIFEST_KEY)]
    if len(candidates) != 1:
        raise RuntimeError('Select exactly one AE Biped armature; found '
                           + str(len(candidates)) + ' possible candidates')
    return candidates[0]


def _main():
    arm = find_rig()
    record = json.loads(str(arm.get(MANIFEST_KEY, '{}')))
    ext = record.get(LEFT_IK_KEY) or {}
    pose = arm.pose.bones
    now = datetime.now(timezone.utc)
    data = {
        'title': 'SaberRig AE Left Arm IK E1.3 - read-only diagnostic',
        'time_utc': now.isoformat(),
        'blender_version': bpy.app.version_string,
        'blend_path': bpy.data.filepath,
        'armature': arm.name,
        'bones_total': len(arm.data.bones),
        'fk_controls': sum(1 for b in arm.data.bones
                           if b.name.startswith('SR_CTRL_AE_')
                           and not b.name.startswith('SR_CTRL_AE_IK_')),
        'ik_controls': sum(1 for b in arm.data.bones
                           if b.name.startswith('SR_CTRL_AE_IK_')),
        'ik_mode': ext.get('mode', 'NOT_INSTALLED'),
        'ik_manifest_version': ext.get('version'),
        'ik_pole_calibration_score': ext.get('pole_calibration_score'),
        'fk_original_memberships': ext.get('fk_original_memberships'),
        'collections': {},
        'current_arm_geometry': None,
        'joint_comparison': {},
        'hinge_transport': None,
        'pole_alignment': None,
        'other_ik_bones': {},
        'warnings': [],
    }

    # Collections derive from the serialized manifests, not assumptions about
    # collection names. Report duplicates only once, in their manifest order.
    collection_names = list(dict.fromkeys(
        [x for x in record.get('collections', []) if isinstance(x,str)] +
        [x for x in ext.get('collections', []) if isinstance(x,str)]
    ))
    for name in collection_names:
        col = arm.data.collections.get(name)
        data['collections'][name] = {
            'exists': col is not None,
            'visible': bool(col.is_visible) if col is not None else None,
            'members': sorted(b.name for b in col.bones) if col is not None else None,
        }

    ad = arm.animation_data
    data['animation'] = {
        'action': ad.action.name if ad and ad.action else None,
        'nla_tracks': len(ad.nla_tracks) if ad else 0,
        'drivers': len(ad.drivers) if ad else 0,
    }

    pole = pose.get(POLE)
    if pole is not None:
        data['pole_control'] = {
            'rest_head': vec3(pole.bone.head_local),
            'evaluated_head': vec3(pole.head),
            'location': vec3(pole.location),
            'parent': pole.parent.name if pole.parent else None,
        }
    else:
        data['warnings'].append('POLE_CONTROL_MISSING')

    for label, source_name, drive_name in zip(LABELS, JOINTS, DRIVES):
        source = pose.get(source_name)
        drive = pose.get(drive_name)
        fk = pose.get('SR_CTRL_AE_' + label)
        mch = pose.get('SR_MCH_AE_' + label)
        data['joint_comparison'][label] = {
            'source_name': source_name,
            'drive_name': drive_name,
            'source_matrix': matrix4(source.matrix) if source else None,
            'drive_matrix': matrix4(drive.matrix) if drive else None,
            'mechanism_matrix': matrix4(mch.matrix) if mch else None,
            'source_to_FK': metrics(source.matrix, fk.matrix)
                if source is not None and fk is not None else None,
            'drive_to_source': metrics(drive.matrix, source.matrix)
                if drive is not None and source is not None else None,
            'mechanism_to_source': metrics(mch.matrix, source.matrix)
                if mch is not None and source is not None else None,
            'mch_constraints': [
                {'name': c.name, 'type': c.type,
                 'influence': float(c.influence),
                 'subtarget': getattr(c, 'subtarget', None)}
                for c in mch.constraints] if mch is not None else [],
        }

    # Directly expose the two candidate rotation sources for the near-straight
    # hinge fallback, and their rest-relative rotations. FK control can be
    # stale in IK mode; the native source is always the selected output.
    source_upper = pose.get(JOINTS[0])
    fk_upper = pose.get('SR_CTRL_AE_UpperArm.L')
    if source_upper is not None and fk_upper is not None:
        native_rest_relative = (source_upper.matrix.to_quaternion() @
            source_upper.bone.matrix_local.to_quaternion().inverted())
        fk_rest_relative = (fk_upper.matrix.to_quaternion() @
            fk_upper.bone.matrix_local.to_quaternion().inverted())
        data['hinge_transport'] = {
            'authoritative_bone': JOINTS[0],
            'mode': data['ik_mode'],
            'native_to_FK_evaluated_rotation_deg': math.degrees(
                source_upper.matrix.to_quaternion().rotation_difference(
                    fk_upper.matrix.to_quaternion()).angle),
            'native_to_FK_rest_relative_rotation_deg': math.degrees(
                native_rest_relative.rotation_difference(fk_rest_relative).angle),
            'native_evaluated_rotation': [float(x) for x in source_upper.matrix.to_quaternion()],
            'fk_control_rotation': [float(x) for x in fk_upper.matrix.to_quaternion()],
            'note': 'FK may lag in IK mode; rest-relative rotations may differ due to distinct rest axes; native source drives near-straight hinge fallback',
        }
    else:
        data['warnings'].append('HINGE_TRANSPORT_COMPARISON_MISSING')

    for name in (IK_HAND, POLE, 'SR_MCH_AE_IK_UpperArm.L',
                 'SR_MCH_AE_IK_Forearm.L'):
        pb = pose.get(name)
        data['other_ik_bones'][name] = {
            'exists': pb is not None,
            'head': vec3(pb.head) if pb else None,
            'tail': vec3(pb.tail) if pb else None,
            'constraints': [
                {'name': c.name, 'type': c.type,
                 'subtarget': getattr(c, 'subtarget', None),
                 'pole_subtarget': getattr(c, 'pole_subtarget', None),
                 'chain_count': getattr(c, 'chain_count', None),
                 'pole_angle_deg': math.degrees(float(getattr(c,'pole_angle',0.0)))}
                for c in pb.constraints] if pb is not None else [],
        }

    if all(pose.get(n) is not None for n in JOINTS):
        a,b,c = (pose[n].head.copy() for n in JOINTS)
        axis = c-a
        l1,l2 = (b-a).length,(c-b).length
        if axis.length > 1e-8 and l1 > 1e-8 and l2 > 1e-8:
            length = l1+l2
            unit_axis = axis.normalized()
            offset = (b-a) - unit_axis*((b-a).dot(unit_axis))
            data['current_arm_geometry'] = {
                'joint_lengths': [l1,l2],
                'reach_fraction': axis.length/length,
                'elbow_offset': offset.length,
                'normalized_elbow_offset': offset.length/length,
                'flex_angle_deg': math.degrees((b-a).angle(c-b)),
                'wrist_to_IK_target': (c-pose[IK_HAND].head).length
                    if pose.get(IK_HAND) is not None else None,
            }
            if pole is not None:
                pole_projected = (pole.head-a) - unit_axis*((pole.head-a).dot(unit_axis))
                pole_info = {
                    'offset': offset.length,
                    'offset_relative_to_reach': offset.length/length,
                    'pole_perpendicular_length': pole_projected.length,
                    'angle_pole_to_elbow_deg': None,
                    'cosine_pole_to_elbow': None,
                    'measurement_stable': offset.length/length > 0.02,
                }
                if offset.length > 1e-8 and pole_projected.length > 1e-8:
                    pole_info['angle_pole_to_elbow_deg'] = math.degrees(
                        pole_projected.angle(offset))
                    pole_info['cosine_pole_to_elbow'] = float(
                        pole_projected.normalized().dot(offset.normalized()))
                else:
                    data['warnings'].append('POLE_ALIGNMENT_SINGULAR_ELBOW_OR_POLE')
                if not pole_info['measurement_stable']:
                    data['warnings'].append('NEAR_STRAIGHT_ELBOW_POLE_ANGLE_IS_NOISY')
                data['pole_alignment'] = pole_info
        else:
            data['warnings'].append('DEGENERATE_CURRENT_ARM_GEOMETRY')
    else:
        data['warnings'].append('NATIVE_JOINTS_MISSING')

    path = os.path.join(tempfile.gettempdir(),
        'SaberRig_AE_IK_Left_E1_3_E2_' + now.strftime('%Y%m%dT%H%M%S_%fZ') + '.json')
    with open(path,'w',encoding='utf-8') as f:
        json.dump(data,f,ensure_ascii=False,indent=2)
    print('SABERRIG AE IK LEFT E1.3 E2:',path)
    print('Mode:',data['ik_mode'],'Bones:',data['bones_total'],
          'FK:',data['fk_controls'],'IK:',data['ik_controls'])
    print('Pole alignment:',data['pole_alignment'])
    print('Hinge transport:',data['hinge_transport'])
    print('Drive-to-source:',{k:v['drive_to_source'] for k,v in data['joint_comparison'].items()})
    return path

_main()
