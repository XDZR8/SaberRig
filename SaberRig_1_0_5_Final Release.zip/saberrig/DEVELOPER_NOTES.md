# SaberRig — Developer Notes

**Release presentation:** SaberRig 1.0.5. **Scope of this pass:** comments,
module docstrings, user-facing names and contributor documentation. Existing
rig-generation behavior and persistent identifiers are not refactored here.

## 1. Architecture and responsibilities

| Module | Responsibility | Safety boundary |
| --- | --- | --- |
| `__init__.py` | Blender metadata, class registration, RNA properties, icon and handler lifecycle | Register and roll back only resources owned by this add-on; preserve registration order and IDs |
| `ui.py` | Sidebar navigation, profile previews, status and operator presentation | Show all profile sections, but never execute another profile's operators merely to populate a preview |
| `engine.py` | Shared profile detection, rig builders, secondary motion, FGO preparation, bake/export and QA operators | Validate ownership/preconditions; do not rewrite imported skinning or change historic identifiers |
| `ae_biped.py` | Endfield biped FK foundation, ownership and removal | Maintain manifest and original pose; do not infer a rig from partial name matches |
| `ae_ik*.py` | Per-limb Endfield IK controls, solver checks and FK/IK transitions | Reject unsafe snaps and partial installs; separate control/mechanism and source bones |
| `ae_leg_foot_follow.py` | Optional Endfield knee-pole behavior | Respect stored preference and lazy guide ownership |
| `ae_collection_org.py` | Endfield Bone Collection organization and restoration | Save exact pre-build memberships and do not edit deform geometry |
| `ae_auto_attachments.py` | Generic dispatch for source-verified attachment migrations | Fail closed for unsupported characters and incomplete attachment groups |
| `ae_si_attachments.py` | Compatibility with Si's audited legacy attachment mapping | Never generalize character-specific destination bones |
| `diagnostics/` | Standalone read-only probes used for development | No persistent changes to bones or materials |

## 2. User-facing terminology vs persistent data

- **Safe to rename:** sidebar descriptions, `bl_label` display strings, user-facing warnings, explanatory comments, documentation and visual preview labels.
- **Do not casually rename:** `bl_idname`, Python operator/class IDs, bone or collection names, constraint prefixes, JSON report keys, custom-property keys, manifest component IDs, stored revision IDs and imported source-bone names.
- Legacy version suffixes in internal IDs identify serialized data and are not evidence of the release version. Put natural-language feature names in the interface; preserve serialized names until a separate migration is designed and tested.
- Do not make UI preview entries call operators. An unsupported profile should show read-only feature discovery, not silently switch the active rig.

## 3. Build and restoration rules

1. Resolve the selected armature and detected profile; do not fall back to an unrelated scene armature.
2. Run structural preflight before any write. A partial or unexpected manifest is not a clean, unprepared rig.
3. Create controls/mechanisms with explicit ownership. Preserve imported rest transforms, weights, twist/facial/corrective bones and existing animation unless a feature explicitly documents a safe change.
4. Prefer repeatable Build/Prepare and guarded FK/IK switching. Validate position, orientation and scale before accepting a pose snap.
5. Record original visibility, memberships, constraints and transforms needed for deterministic removal; report incomplete restoration instead of claiming success.
6. On file load, Undo or Redo, invalidate transient runtime caches that may hold stale Blender RNA references.

## 4. Comment and naming conventions

- Comment on **why an operation is safe**, not only what its next line does.
- Explain coordinate spaces (rest/pose/world), joint reach, pole stability, source versus mechanism bones and solver edge cases where applicable.
- Describe whether a procedure is read-only, reversible, idempotent, or intentionally experimental. Do not imply scene-level validation from an offline test.
- Prefer user text such as **Left Arm FK/IK (Experimental)** over milestone labels like `E1.4`; retain milestones in developer history or identifiers when required for compatibility.
- Avoid broad mechanical renaming passes over `engine.py`: many numeric identifiers are used as exact manifest/probe keys.

## 5. Release and compatibility review

The installed add-on metadata is `bl_info.version = (1, 0, 5)`. Separately,
`engine.ADDON_VERSION` and `engine.SR_RELEASE_CANDIDATE` currently still store
`"1.0.1"`; those constants are written into generated rig metadata and were
**intentionally not changed** by this documentation-only pass. Release-number alignment should be reviewed separately against saved-scene migration behavior.

## 6. Blender regression checklist

- Install/enable/disable/re-enable: class registration, sidebar icon, handler removal and absence of duplicate callbacks.
- Every game profile remains visible; an incompatible profile presents disabled feature descriptions instead of active operations.
- General/MMD and Uma: foundation, arm/leg IK and FK, fingers, animation spaces, secondary motion and Remove Setup.
- FGO Arcade: Prepare twice; arm/leg FK/IK switching; upper-arm/thigh auxiliary deformation; Foot Follow, pelvis squat and torso lean; export and restoration.
- Endfield biped: preflight, Build, left/right arm/leg IK, both knee poles, optional Foot Follow, attachments and bone collection restoration.
- Inspect source bone counts, weights and transforms before/after; test an unsuccessful operation and its rollback.
- Verify saved .blend compatibility with a build from the preceding release. Run native Blender tests, not only Python syntax checks.
