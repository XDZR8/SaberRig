# SaberRig — License and third-party notices

SaberRig project repository: https://github.com/XDZR8/SaberRig

## Source-code license

The public SaberRig repository identifies the project as licensed under the GNU General Public License v3.0 (GPL-3.0). The complete GPL version 3 text is provided in `LICENSE` alongside the Blender add-on source.

**Notice requiring maintainer review before a public release:** The preserved Python module headers in this release state `SPDX-License-Identifier: GPL-2.0-or-later`, whereas the public repository identifies GPL-3.0. GPL-2.0-or-later permits choosing GPL version 3 for redistribution, but the combination should be documented consistently by the copyright holder. These headers have deliberately not been changed in this documentation-only update. Please check ownership and any contributor/third-party notices before changing license identifiers.

Modified distributions must retain appropriate original copyright and license notices, the source code and the GPL license text; mark modifications and dates as required by GPLv3. This note does not add or remove license grants.

## Game names and IP

`Fate/Grand Order Arcade`, `Uma Musume`, and `Arknights: Endfield` are used solely as names of interoperability profiles. SaberRig is an independent Blender add-on; it is not affiliated with, sponsored by or endorsed by the games' publishers or rightsholders.

No game models, textures, animations, audio or extracted asset packages are included in this release. The optional image `saberrig/assets/SaberRig_icon.png` was provided for the SaberRig project; confirm rights to publicly redistribute it and confirm the authorship of all independently incorporated code before publishing.

A jurisdiction- and use-dependent rights assessment, with links to official policies and outstanding risks, is in `IP_POLICY_REVIEW_ES.md`. A software license never licenses third-party game resources.
