# SaberRig 1.0.1

Native Blender 5.1.1 rigging add-on with profile-based preparation and animation controls.

## Installation

Install `SaberRig_1_0_1_Blender_Addon.zip` from **Edit → Preferences → Add-ons → Install from Disk**. Do not unzip before installing. Restart Blender, then open **3D Viewport → N → SaberRig**.

The logo is bundled in `saberrig/assets/SaberRig_icon.png` and loaded as an optional Blender preview. It has no external dependency.

## Interface

- **Prepare SaberRig** detects the selected armature and invokes the appropriate preparation.
- **General / MMD** offers the shared humanoid rigging controls.
- **Uma Musume** shows MMD-hybrid tools and the existing secondary-motion controls.
- **FGO Arcade** contains the prepared IK/FK controls, Knee Follow, thigh and arm auxiliary bindings, planted-foot squat and torso lean.
- **Arknights: Endfield** exposes shared semantic rig tools with experimental warnings where appropriate.
- **QA & Reports** is nested under FGO Arcade. Historical diagnostic operator implementations remain in the engine for compatibility, but no Legacy Tools panel is shown.

## Package layout

```
saberrig/
    __init__.py      Blender metadata, operator registration and lifecycle
    engine.py        Profile detection, rig creation, animation and QA operators
    ui.py            Native sidebar panels and bundled logo handling
    assets/
        SaberRig_icon.png
```

## Compatibility and scope

The user-facing add-on version is **1.0.1**.

This revision changes packaging, UI labels, documentation and developer comments. It does not reimplement IK solvers or change user rig data. Blender runtime behavior still requires testing in Blender 5.1.1, including fresh installation and a prepared FGO rig.
