# SaberRig source

The package separates Blender registration, UI drawing and rigging behavior.

- `saberrig/__init__.py` is deliberately small: it owns version metadata, the class registration sequence and cache/icon lifecycle.
- `saberrig/ui.py` is the only place for sidebar layouts, logo previews and profile navigation. All its buttons invoke existing engine operators.
- `saberrig/engine.py` retains rig-generation and diagnostic code in its original execution order to avoid changing cross-component behavior and generated-data compatibility. Future domain extraction can proceed once Blender integration tests cover each rig profile.

Comments describe constraints, preconditions, coordinate systems, restoration behavior and user-visible effects. Component identifiers containing historical numerals remain untouched because they are stored in Blender projects and test reports. Do not rename them during cosmetic refactors.

Regression checklist: Blender add-on registration, icon loaded/unloaded, correct five UI sections, FGO Prepare twice, arm/leg IK-FK changes, thigh and arm auxiliary deformation, Follow Pole, squat and forward lean, generic preparation, secondary motion and remove setup.
