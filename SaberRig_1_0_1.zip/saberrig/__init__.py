# SPDX-License-Identifier: GPL-2.0-or-later
# -*- coding: utf-8 -*-
"""SaberRig add-on entrypoint and Blender class registration.

The rigging engine and the native sidebar UI are separate modules. Imported
scene metadata and generated bone/constraint identifiers remain compatible.
"""

bl_info = {
    "name": "SaberRig",
    "author": "SaberRig Project",
    "version": (1, 0, 1),
    "blender": (5, 1, 1),
    "location": "View3D > Sidebar > SaberRig",
    "description": "Multi-profile rigging, IK/FK animation and FGO Arcade preparation",
    "category": "Rigging",
}

import bpy
from . import engine, ui

# Register property groups and operators first, then parent and child panels.
CLASSES = (
    engine.SR_MappingItem,
    engine.SR_CountItem,
    engine.SR_MessageItem,
    engine.SR_AnalysisState,
    engine.SR_OT_AnalyzeRig,
    engine.SR_OT_AnalyzeFGOArcade,
    engine.SR_OT_ExportFGOAudit,
    engine.SR_OT_FGO35Calibrate,
    engine.SR_OT_FGO35StartPreview,
    engine.SR_OT_FGO35RemovePreview,
    engine.SR_OT_FGO35TestPose,
    engine.SR_OT_FGO35RestorePose,
    engine.SR_OT_FGO35ExportCalibration,
    engine.SR_OT_FGO36BuildControls,
    engine.SR_OT_FGO36Switch,
    engine.SR_OT_FGO36Reset,
    engine.SR_OT_FGO36Remove,
    engine.SR_OT_FGO363SetVisibility,
    engine.SR_OT_FGO363RestoreVisibility,
    engine.SR_OT_FGO364FindIKControl,
    engine.SR_OT_FGO365MotionProbe,
    engine.SR_OT_FGO367AuditCurrentIK,
    engine.SR_OT_FGO365ExportMotionReport,
    engine.SR_OT_FGO368AuditLayers,
    engine.SR_OT_FGO368ReachSweep,
    engine.SR_OT_FGO368ExportReport,
    engine.SR_OT_FGO369AuxiliaryAudit,
    engine.SR_OT_FGO369TransferSweep,
    engine.SR_OT_FGO369ExportReport,
    engine.SR_OT_FGO3610StartPreview,
    engine.SR_OT_FGO3610SetInfluence,
    engine.SR_OT_FGO3610Sweep,
    engine.SR_OT_FGO3610RemovePreview,
    engine.SR_OT_FGO3610ExportReport,
    engine.SR_OT_FGO3611EnableBoth,
    engine.SR_OT_FGO3611BuildRight,
    engine.SR_OT_FGO3611SetRight,
    engine.SR_OT_FGO3611RemoveRight,
    engine.SR_OT_FGO3611BilateralSweep,
    engine.SR_OT_FGO3611SwitchQA,
    engine.SR_OT_FGO3611Export,
    engine.SR_OT_FGO3612StructureAudit,
    engine.SR_OT_FGO3612LegSweep,
    engine.SR_OT_FGO3612Export,
    engine.SR_OT_FGO3613Build,
    engine.SR_OT_FGO3613Influence,
    engine.SR_OT_FGO3613Sweep,
    engine.SR_OT_FGO3613PelvisPreview,
    engine.SR_OT_FGO3613LegSwitch,
    engine.SR_OT_FGO3613Remove,
    engine.SR_OT_FGO3613Export,
    engine.SR_OT_FGO36131Build,
    engine.SR_OT_FGO36131Set,
    engine.SR_OT_FGO36131Sweep,
    engine.SR_OT_FGO36131Remove,
    engine.SR_OT_FGO36131Export,
    engine.SR_OT_FGO361321GuardInspect,
    engine.SR_OT_FGO361321GuardRecover,
    engine.SR_OT_FGO36132Build,
    engine.SR_OT_FGO36132Mode,
    engine.SR_OT_FGO36132Sweep,
    engine.SR_OT_FGO36132Remove,
    engine.SR_OT_FGO36132Export,
    engine.SR_OT_FGO36143Repair,
    engine.SR_OT_FGO36143Diagnose,
    engine.SR_OT_FGO36143Export,
    engine.SR_OT_FGO36142Build,
    engine.SR_OT_FGO36142QA,
    engine.SR_OT_FGO36142Remove,
    engine.SR_OT_FGO36142Export,
    engine.SR_OT_FGO3614Build,
    engine.SR_OT_FGO3614Select,
    engine.SR_OT_FGO3614QA,
    engine.SR_OT_FGO3614Remove,
    engine.SR_OT_FGO3614Export,
    engine.SR_OT_ClearAnalysis,
    engine.SR_OT_ExportAnalysis,
    engine.SR_OT_RunRigQA,
    engine.SR_OT_ExportRigQA,
    engine.SR_OT_BakeToSource,
    engine.SR_OT_BakeCleanExport,
    engine.SR_OT_SelectMappedBone,
    engine.SR_OT_FGO3615Prepare,
    engine.SR_OT_PrepareFoundation,
    engine.SR_OT_BuildBodyControls,
    engine.SR_OT_BuildFingerControls,
    engine.SR_OT_ResetFingerControls,
    engine.SR_OT_BuildArmsFK,
    engine.SR_OT_BuildArmsIK,
    engine.SR_OT_SetArmMode,
    engine.SR_OT_SetArmJointLimits,
    engine.SR_OT_SetShoulderAssist,
    engine.SR_OT_BuildAnimationSpaces,
    engine.SR_OT_SetAnimationSpace,
    engine.SR_OT_BuildLegsIK,
    engine.SR_OT_SetLegMode,
    engine.SR_OT_SetLegJointLimits,
    engine.SR_OT_SetLegBendMode,
    engine.SR_OT_SetKneePoleSpace,
    engine.SR_OT_ResetFootRoll,
    engine.SR_OT_BuildSecondaryMotion,
    engine.SR_OT_BuildUmaWiggle,
    engine.SR_OT_ToggleWiggle,
    engine.SR_OT_ToggleWiggleFamily,
    engine.SR_OT_ResetWiggle,
    engine.SR_OT_RemoveWiggle,
    engine.SR_OT_SetRigView,
    engine.SR_OT_RefreshControlVisuals,
    engine.SR_OT_RemoveSetup,
    ui.SR_PT_MainPanel,
    ui.SR_PT_GeneralMMDPanel,
    ui.SR_PT_UmaMusumePanel,
    ui.SR_PT_FGOArcadePanel,
    ui.SR_PT_RigControlsPanel,
    ui.SR_PT_EndfieldPanel,
    ui.SR_PT_FGOPosePanel,
    ui.SR_PT_FGOQualityPanel,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.saberrig_state = bpy.props.PointerProperty(type=engine.SR_AnalysisState)
    ui._register_brand_icon()
    engine._ensure_wiggle_handler()


def unregister():
    ui._unregister_brand_icon()
    engine._remove_wiggle_handler()
    engine._WIGGLE_STATE.clear()
    engine._WIGGLE_CACHE.clear()
    engine._ANALYSIS_CACHE.clear()
    engine._FGO35_CALIBRATION_CACHE.clear()
    if hasattr(bpy.types.Scene, 'saberrig_state'):
        del bpy.types.Scene.saberrig_state
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


if __name__ == '__main__':
    register()
