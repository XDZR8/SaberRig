# SPDX-License-Identifier: GPL-2.0-or-later
# -*- coding: utf-8 -*-
"""Sidebar panels, profile navigation and bundled logo resources.

UI callbacks reuse the rigging operators in :mod:`engine`; this module does not
create or change deform bones, constraints or animation data itself.
"""

import os
import json
import bpy
import bpy.utils.previews
from bpy.types import Panel
from .engine import (
    SR_SUPPORTED_PROFILE_IDS,
    _FGO3615_REPORT_KEY,
    _detect_profile,
    _fgo36132_manifest,
    _fgo3615_state,
    _fgo36_manifest,
    _fgo_is_candidate,
    _foundation_is_prepared,
    _resolve_armature,
    _secondary_preset_for_profile,
)


# The optional native Blender preview icon is not a rig-preparation dependency.
# The image is stored in the installed add-on package.
_BRAND_PREVIEWS = None
_BRAND_ICON_ID = 0


def _register_brand_icon():
    global _BRAND_PREVIEWS, _BRAND_ICON_ID
    if _BRAND_PREVIEWS is not None:
        return
    previews = None
    try:
        asset_path = os.path.join(os.path.dirname(__file__), 'assets', 'SaberRig_icon.png')
        if not os.path.isfile(asset_path):
            return
        previews = bpy.utils.previews.new()
        previews.load('saberrig_logo', asset_path, 'IMAGE')
        _BRAND_ICON_ID = int(previews['saberrig_logo'].icon_id)
        _BRAND_PREVIEWS = previews
    except Exception as exc:
        if previews is not None:
            try:
                bpy.utils.previews.remove(previews)
            except Exception:
                pass
        _BRAND_PREVIEWS = None
        _BRAND_ICON_ID = 0
        print('SaberRig: optional header icon unavailable:', exc)


def _unregister_brand_icon():
    global _BRAND_PREVIEWS, _BRAND_ICON_ID
    previews = _BRAND_PREVIEWS
    _BRAND_PREVIEWS = None
    _BRAND_ICON_ID = 0
    if previews is not None:
        try:
            bpy.utils.previews.remove(previews)
        except Exception:
            pass


def _current_profile(context, arm):
    """Read profile without assuming that another armature's analysis is current."""
    if arm is None:
        return None
    if _fgo_is_candidate(arm):
        return 'FGO_ARCADE'
    state = context.scene.saberrig_state
    registered = str(arm.get('saberrig_profile_id', '')).strip()
    if registered in SR_SUPPORTED_PROFILE_IDS or registered == 'GENERIC_HUMANOID':
        return registered
    if bool(state.analyzed) and state.armature_name == arm.name:
        return state.profile_id or 'GENERIC_HUMANOID'
    # Profile identification uses bone names until a full analysis is requested; the
    # active profile must remain visible before pressing Analyze/Prepare.
    try:
        profile, _score, _evidence, _scores = _detect_profile([b.name for b in arm.data.bones])
        return str(profile['id'])
    except Exception:
        return 'GENERIC_HUMANOID'


def _profile_label(profile_id):
    return {
        'FGO_ARCADE': 'FGO Arcade',
        'UMA_MUSUME_MMD_HYBRID': 'Uma Musume',
        'MMD_STANDARD': 'General / MMD',
        'GENERIC_HUMANOID': 'General / MMD',
        'ENDFIELD_SEGMENTED': 'Endfield (Segmented)',
        'ENDFIELD_BIPED': 'Endfield (Biped)',
    }.get(profile_id, 'General / MMD')


def _profile_notice(layout, profile_id, allowed):
    if profile_id not in allowed:
        box = layout.box()
        box.label(text='Selected rig: ' + _profile_label(profile_id), icon='INFO')
        box.label(text='Select a compatible armature to use these tools')
        return False
    return True


def _generic_builders(layout, arm, profile_name, experimental=False):
    """Selected existing generic operators; no new bone-building behavior."""
    prepared = _foundation_is_prepared(arm)
    status = layout.box()
    status.label(text=profile_name + ' / Shared Rigging Tools', icon='ARMATURE_DATA')
    status.label(text='Foundation ready' if prepared else 'Run Prepare SaberRig first',
                 icon='CHECKMARK' if prepared else 'INFO')
    if experimental:
        status.label(text='Generic mapping: inspect deformation after each build', icon='ERROR')
    tools = status.column(align=True)
    tools.enabled = bool(prepared)
    for flag, op_id, title, icon in (
        ('saberrig_body_built', 'saberrig.build_body_controls', 'Body / COG', 'CON_TRACKTO'),
        ('saberrig_arms_fk_built', 'saberrig.build_arms_fk', 'Arms FK', 'BONE_DATA'),
        ('saberrig_arms_ik_built', 'saberrig.build_arms_ik', 'Arms IK', 'CON_KINEMATIC'),
        ('saberrig_legs_ik_built', 'saberrig.build_legs_ik', 'Legs IK', 'CON_KINEMATIC'),
        ('saberrig_fingers_built', 'saberrig.build_finger_controls', 'Finger Controls', 'HAND'),
        ('saberrig_animation_spaces_built', 'saberrig.build_animation_spaces', 'Animation Spaces', 'CON_CHILDOF'),
    ):
        row = tools.row(align=True)
        installed = bool(arm.get(flag, False))
        row.operator(op_id, text=('Refresh ' if installed else 'Build ') + title,
                     icon='CHECKMARK' if installed else icon)

    if arm.get('saberrig_arms_ik_built', False):
        sub = status.box()
        sub.label(text='Arm IK / FK', icon='HAND')
        for side in ('L', 'R'):
            mode = str(arm.get('saberrig_arm_mode_' + side, 'FK'))
            row = sub.row(align=True)
            row.label(text='Arm ' + side)
            for m in ('FK', 'IK'):
                op = row.operator('saberrig.set_arm_mode', text=m, depress=mode==m)
                op.side, op.mode = side, m

    if arm.get('saberrig_legs_ik_built', False):
        sub = status.box()
        sub.label(text='Leg IK / FK', icon='CON_KINEMATIC')
        for side in ('L', 'R'):
            mode = str(arm.get('saberrig_leg_mode_' + side, 'FK'))
            row = sub.row(align=True)
            row.label(text='Leg ' + side)
            for m in ('FK', 'IK'):
                op = row.operator('saberrig.set_leg_mode', text=m, depress=mode==m)
                op.side, op.mode = side, m

    row = status.row(align=True)
    row.enabled = bool(prepared)
    op = row.operator('saberrig.set_rig_view', text='Controls Only', icon='HIDE_OFF')
    op.mode = 'CONTROLS'
    op = row.operator('saberrig.set_rig_view', text='Source View', icon='HIDE_ON')
    op.mode = 'SOURCE'


def _secondary(layout, arm, profile_name):
    box = layout.box()
    box.label(text='Secondary Motion', icon='PHYSICS')
    preset = _secondary_preset_for_profile(_current_profile_from_arm(arm))
    box.label(text='Preset: ' + str(preset.get('name', 'Semantic')))
    row = box.row(align=True)
    row.enabled = _foundation_is_prepared(arm)
    built = bool(arm.get('saberrig_wiggle_built', False))
    row.operator('saberrig.build_secondary_motion',
                 text='Rebuild Secondary' if built else 'Build Secondary', icon='PHYSICS')
    if built:
        on = bool(arm.get('saberrig_wiggle_enabled', True))
        row = box.row(align=True)
        for flag, label in ((True, 'On'), (False, 'Off')):
            op = row.operator('saberrig.toggle_wiggle', text=label, depress=on==flag)
            op.enabled = flag
        row.operator('saberrig.reset_wiggle', text='Reset', icon='RECOVER_LAST')


def _current_profile_from_arm(arm):
    return str(arm.get('saberrig_profile_id', 'GENERIC_HUMANOID'))

def _confidence_icon(value):
    if value >= 0.85:
        return 'CHECKMARK'
    if value >= 0.60:
        return 'INFO'
    return 'ERROR'

def _find_mapping(state, role):
    for item in state.mappings:
        if item.role == role:
            return item
    return None


class SR_PT_MainPanel(Panel):
    bl_label = 'SaberRig'
    bl_order = 0
    bl_idname = 'SR_PT_main'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'SaberRig'

    def draw(self, context):
        layout = self.layout
        state = context.scene.saberrig_state
        arm = _resolve_armature(context, state)
        profile = _current_profile(context, arm)
        fgo = bool(arm and profile == 'FGO_ARCADE')

        box = layout.box()
        head = box.row(align=True)
        if _BRAND_ICON_ID:
            head.template_icon(icon_value=_BRAND_ICON_ID, scale=5.0)
        else:
            head.label(text='', icon='ARMATURE_DATA')
        title = head.column(align=True)
        title.label(text='SaberRig', icon='ARMATURE_DATA')
        title.label(text='Version 1.0.1')
        title.label(text='Rigging Workspace')

        if not arm:
            box.label(text='Select an armature to begin', icon='INFO')
        else:
            info = box.column(align=True)
            info.label(text='Target: ' + arm.name[:48], icon='OUTLINER_OB_ARMATURE')
            info.label(text='Profile: ' + _profile_label(profile), icon='BONE_DATA')
            if fgo:
                status = _fgo3615_state(arm)
                info.label(text='FGO setup: %d/%d ready' %
                           (status.get('count', 0), status.get('total', 8)),
                           icon='CHECKMARK' if status.get('ready') else 'INFO')
            else:
                ready = _foundation_is_prepared(arm)
                info.label(text='Foundation: ' + ('Prepared' if ready else 'Not prepared'),
                           icon='CHECKMARK' if ready else 'INFO')

        row = box.row()
        row.scale_y = 1.4
        row.enabled = bool(arm)
        if fgo:
            ready = _fgo3615_state(arm).get('ready', False)
            row.operator('saberrig.fgo3615_prepare',
                         text='Recheck / Resume FGO' if ready else 'Prepare SaberRig',
                         icon='CHECKMARK' if ready else 'ARMATURE_DATA')
        else:
            ready = bool(arm and _foundation_is_prepared(arm))
            row.operator('saberrig.prepare_foundation',
                         text='Recheck Foundation' if ready else 'Prepare SaberRig',
                         icon='CHECKMARK' if ready else 'ARMATURE_DATA')
        row = layout.row(align=True)
        row.operator('saberrig.analyze_rig', text='Analyze', icon='VIEWZOOM')
        row.operator('saberrig.run_rig_qa', text='Validate', icon='CHECKMARK')
        if fgo:
            status = _fgo3615_state(arm)
            if status.get('error'):
                col = layout.column(align=True)
                col.alert = True
                col.label(text='FGO preparation needs attention', icon='ERROR')
            try:
                result = json.loads(str(arm.get(_FGO3615_REPORT_KEY, '{}')))
                if result.get('status') == 'INCOMPLETE':
                    row = layout.row()
                    row.alert = True
                    row.label(text='Stopped: ' + str(result.get('failed_stage', '?'))[:40], icon='ERROR')
            except Exception:
                pass
        # Profile panels are organized below the main preparation controls.


class SR_PT_GeneralMMDPanel(Panel):
    bl_label = 'General / MMD'
    bl_order = 10
    bl_idname = 'SR_PT_general_mmd'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'SaberRig'
    bl_parent_id = 'SR_PT_main'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        arm = _resolve_armature(context, context.scene.saberrig_state)
        if arm is None:
            layout.label(text='Select an armature to start', icon='INFO')
            return
        profile = _current_profile(context, arm)
        if not _profile_notice(layout, profile, ('GENERIC_HUMANOID', 'MMD_STANDARD')):
            return
        _generic_builders(layout, arm, 'General / MMD')
        if _foundation_is_prepared(arm):
            _secondary(layout, arm, 'General / MMD')
        layout.label(text='Source weights and original hierarchy are preserved', icon='LOCKED')


class SR_PT_UmaMusumePanel(Panel):
    bl_label = 'Uma Musume'
    bl_order = 20
    bl_idname = 'SR_PT_uma_musume'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'SaberRig'
    bl_parent_id = 'SR_PT_main'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        arm = _resolve_armature(context, context.scene.saberrig_state)
        if arm is None:
            layout.label(text='Select an Uma armature', icon='INFO')
            return
        profile = _current_profile(context, arm)
        if not _profile_notice(layout, profile, ('UMA_MUSUME_MMD_HYBRID',)):
            return
        layout.label(text='Uma / MMD Hybrid | semantic controllers', icon='BONE_DATA')
        _generic_builders(layout, arm, 'Uma Musume', experimental=True)
        if _foundation_is_prepared(arm):
            _secondary(layout, arm, 'Uma Musume')
            layout.label(text='Finger curl and thumb calibration are UMA-aware', icon='INFO')


class SR_PT_EndfieldPanel(Panel):
    bl_label = 'Arknights: Endfield'
    bl_order = 40
    bl_idname = 'SR_PT_endfield'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'SaberRig'
    bl_parent_id = 'SR_PT_main'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        arm = _resolve_armature(context, context.scene.saberrig_state)
        if arm is None:
            layout.label(text='Select an Endfield armature', icon='INFO')
            return
        profile = _current_profile(context, arm)
        if not _profile_notice(layout, profile,
              ('ENDFIELD_SEGMENTED', 'ENDFIELD_BIPED')):
            return
        layout.label(text='Detected: ' + _profile_label(profile), icon='CHECKMARK')
        _generic_builders(layout, arm, 'Endfield', experimental=True)
        if _foundation_is_prepared(arm):
            _secondary(layout, arm, 'Endfield')
        layout.label(text='No dedicated FGO-style auto-rig for Endfield yet', icon='INFO')
        layout.label(text='Validate mapping before building more controls', icon='INFO')


class SR_PT_RigControlsPanel(Panel):
    bl_label = "Animation Controls"
    bl_order = 0
    bl_idname = "SR_PT_animation_controls"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "SaberRig"
    bl_parent_id = "SR_PT_fgo_arcade"

    def draw(self, context):
        layout = self.layout
        state = context.scene.saberrig_state
        arm = _resolve_armature(context, state)
        if not arm:
            layout.label(text="Select an armature", icon='INFO')
            return
        if not _fgo_is_candidate(arm):
            layout.label(text="Use General / MMD for shared rig controls", icon='INFO')
            return
        manifest = _fgo36_manifest(arm)
        if not manifest:
            layout.label(text="Run Prepare SaberRig first", icon='INFO')
            return
        chains = manifest.get('chains', {})
        for key, label, icon in (
            ('ARM_L','Left Arm','HAND'), ('ARM_R','Right Arm','HAND'),
            ('LEG_L','Left Leg','CON_KINEMATIC'), ('LEG_R','Right Leg','CON_KINEMATIC')):
            spec = chains.get(key)
            if not spec:
                continue
            mode = spec.get('mode', 'FK')
            row = layout.row(align=True)
            row.label(text=label, icon=icon)
            for target in ('FK','IK'):
                op = row.operator('saberrig.fgo36_switch', text=target, depress=mode==target)
                op.chain = key
                op.mode = target
        row = layout.row(align=True)
        for chain, name in (('ARM_L','Hand L'),('ARM_R','Hand R')):
            op = row.operator('saberrig.fgo364_find_ik_control', text=name, icon='VIEWZOOM')
            op.chain = chain
        row = layout.row(align=True)
        for chain, name in (('LEG_L','Foot L'),('LEG_R','Foot R')):
            op = row.operator('saberrig.fgo364_find_ik_control', text=name, icon='VIEWZOOM')
            op.chain = chain
        layout.prop(arm,'show_in_front',text='Controls In Front')


class SR_PT_FGOArcadePanel(Panel):
    bl_label = "FGO Arcade"
    bl_order = 30
    bl_idname = "SR_PT_fgo_arcade"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "SaberRig"
    bl_parent_id = "SR_PT_main"

    def draw(self, context):
        layout = self.layout
        arm = _resolve_armature(context, context.scene.saberrig_state)
        if not arm or not _fgo_is_candidate(arm):
            layout.label(text='Select an FGO Arcade armature', icon='INFO')
            return
        status = _fgo3615_state(arm)
        box = layout.box()
        box.label(text='Use Prepare SaberRig in the main header', icon='INFO')
        flags = status.get('flags', {})
        for title, keys in (
            ('Skeleton & IK/FK',('bridge','ikfk','leg_ik')),
            ('Arms & Thighs',('arms','thighs')),
            ('Knee Follow',('poles',)),
            ('Squat & Torso Lean',('squat','lean'))):
            passed = all(flags.get(key, False) for key in keys)
            row = box.row(align=True)
            row.label(text=title, icon='CHECKMARK' if passed else 'RADIOBUT_OFF')
            row.label(text='Ready' if passed else 'Pending')
        if not status.get('ready'):
            box.label(text='Prepare runs the verified setup in order', icon='INFO')
        box.label(text='Extension guard not part of the verified FGO preset', icon='LOCKED')


class SR_PT_FGOPosePanel(Panel):
    bl_label = "Pelvis, Knees & Pose"
    bl_order = 10
    bl_idname = "SR_PT_fgo_pose"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "SaberRig"
    bl_parent_id = "SR_PT_fgo_arcade"

    def draw(self, context):
        layout = self.layout
        arm = _resolve_armature(context, context.scene.saberrig_state)
        status = _fgo3615_state(arm)
        flags = status.get('flags', {})
        row = layout.row()
        row.enabled = bool(flags.get('squat'))
        row.scale_y = 1.25
        row.operator('saberrig.fgo3614_select', text='Select Pelvis  (lowerbody_jo)', icon='BONE_DATA')
        layout.label(text='Move pelvis down to squat; forward to lean', icon='INFO')
        guide = _fgo36132_manifest(arm)
        if guide:
            box = layout.box()
            box.label(text='Knee Plane', icon='CON_KINEMATIC')
            row = box.row(align=True)
            for target, label in (('FOLLOW','Foot Follow'),('STATIC','Original Pole')):
                op = row.operator('saberrig.fgo36132_mode', text=label,
                                  depress=(target=='FOLLOW' and bool(flags.get('poles'))))
                op.mode = target
            box.label(text='Foot Follow is the verified FGO preset', icon='INFO')
        row = layout.row(align=True)
        row.enabled = bool(flags.get('lean'))
        row.operator('saberrig.fgo36143_diagnose', text='Verify Torso Lean', icon='CHECKMARK')


class SR_PT_FGOQualityPanel(Panel):
    bl_label = "QA & Reports"
    bl_order = 20
    bl_idname = "SR_PT_fgo_quality"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "SaberRig"
    bl_parent_id = "SR_PT_fgo_arcade"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        arm = _resolve_armature(context, context.scene.saberrig_state)
        status = _fgo3615_state(arm)
        flags = status.get('flags', {})
        row = layout.row(align=True)
        row.operator('saberrig.analyze_fgo_arcade', text='Analyze FGO', icon='VIEWZOOM')
        row.operator('saberrig.fgo35_export_calibration', text='Bridge Report', icon='EXPORT')
        row = layout.row()
        row.enabled = bool(flags.get('poles'))
        row.operator('saberrig.fgo36132_sweep', text='3-Path Knee QA (restore)', icon='CON_KINEMATIC')
        row = layout.row()
        row.enabled = bool(flags.get('squat'))
        row.operator('saberrig.fgo3614_qa', text='5-Step Squat QA (restore)', icon='CON_KINEMATIC')
        row = layout.row()
        row.enabled = bool(flags.get('lean'))
        row.operator('saberrig.fgo36143_diagnose', text='Live Lean QA (restore)', icon='CHECKMARK')
        row = layout.row(align=True)
        row.operator('saberrig.fgo36132_export', text='Knee JSON', icon='EXPORT')
        row.operator('saberrig.fgo36143_export', text='Lean JSON', icon='EXPORT')
        layout.label(text='Tests restore their original pose', icon='INFO')
