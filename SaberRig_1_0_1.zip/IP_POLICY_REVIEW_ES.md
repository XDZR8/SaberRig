# SaberRig 1.0.1 — Revisión preliminar de licencias y políticas de propiedad intelectual

Fecha de consulta: 14 de noviembre de 2026.

**Alcance:** distribución de un complemento de Blender para crear y manipular rigging de modelos que el usuario importe, sin incluir modelos, texturas, animaciones, música, archivos de los juegos, utilidades de extracción ni instrucciones para sortear protecciones. No constituye asesoramiento jurídico ni autoriza por sí mismo la obtención o el uso de recursos de terceros.

## Resultado general

**La distribución del código autónomo de rigging parece sustancialmente menos arriesgada que distribuir assets extraídos, pero no es posible certificar cumplimiento universal solo por no incluir modelos.** La forma en que se obtuvieron los modelos o referencias de esqueleto y cómo se usa/publica el contenido también cuenta. Las normas difieren por juego y pueden cambiar.

| Perfil | Conclusión de la revisión | Precaución |
|---|---|---|
| General / MMD | MMD/PMX es un formato/ecosistema, no una autorización colectiva para utilizar todos los modelos. | Revisar las condiciones particulares de cada modelo, especialmente edición, conversión y redistribución. |
| Uma Musume | La política oficial de obras derivadas admite actividad fan dentro de límites y desaconseja lo comercial; las condiciones del servicio restringen ingeniería inversa, reproducción/modificación del servicio y herramientas externas que afecten al juego. | El addon no debe extraer datos del cliente ni distribuir modelos o materiales oficiales. No presentar el perfil como licencia de assets. |
| FGO Arcade | Las condiciones oficiales prohíben analizar, alterar o aplicar ingeniería inversa al videojuego y facilitar herramientas o datos que hagan posibles actos prohibidos. | No incorporar extracción del juego, métodos de elusión ni archivos obtenidos sin autorización. La presencia de nombres técnicos o mapeos no garantiza estar fuera del alcance de esas cláusulas: revisar procedencia y condiciones. |
| Arknights: Endfield | La guía oficial permite determinados trabajos fan 3D no lucrativos, pero el comunicado Fair Play prohíbe desempaquetar o modificar los archivos de instalación y distribuir materiales extraídos. | Separar creación 3D original de extracción de recursos del cliente. La guía también prohíbe archivos para determinadas figuritas y productos tridimensionales físicos. |

## Licencia de SaberRig

El repositorio público https://github.com/XDZR8/SaberRig contiene un archivo `LICENSE` con **GNU GPL v3.0**. Se adjunta una copia del texto estándar de GPLv3 al paquete. El código distribuido sigue teniendo cabeceras `SPDX-License-Identifier: GPL-2.0-or-later` en `__init__.py`, `engine.py` y `ui.py`: GPLv3 es una de las versiones permitidas por `-or-later`, pero los avisos deberían verificarse y uniformarse por el titular de derechos, conservando el historial de atribución. No se ha cambiado esta licencia ni atribuido nuevos derechos en esta revisión.

Si se publica el addon modificado, se debe mantener la GPL aplicable, proporcionar el código fuente correspondiente y el texto de licencia, conservar atribuciones pertinentes e identificar modificaciones. La GPL del addon **no** cubre automáticamente propiedad intelectual de las empresas de videojuegos.

## Fuentes oficiales comprobadas

1. SaberRig — repositorio y licencia: https://github.com/XDZR8/SaberRig y https://github.com/XDZR8/SaberRig/blob/main/LICENSE
2. Fate/Grand Order Arcade — términos oficiales: https://arcade.fate-go.jp/userpolicy/ (sección de prohibiciones de análisis, modificación, ingeniería inversa y distribución de herramientas o datos que faciliten estas conductas). Titularidad indicada por SEGA: ©TYPE-MOON / FGO ARCADE PROJECT: https://www.sega.jp/arcade/detail/arcade-fate-go/
3. Uma Musume — guía oficial de obras derivadas: https://umamusume.jp/derivativework_guidelines/ y términos oficiales: https://umamusume.jp/terms/ (restricciones sobre ingeniería inversa, cambios del servicio, software externo y contenidos lucrativos fuera de la actividad fan).
4. Arknights: Endfield — Fan Content and Streaming Guidelines (2026-02-03): https://endfield.gryphline.com/en-us/news/4497 ; Fair Play Statement (2026-01-20): https://endfield.gryphline.com/en-us/news/8900

## Riesgos aún abiertos / límites de la verificación

- **Procedencia de los modelos de prueba.** No se ha verificado si su extracción, conversión, importación o posterior publicación está permitida por sus respectivas licencias.
- **Nombres de huesos y parámetros derivados de juegos.** Un addon capaz de reconocer jerarquías no equivale necesariamente a una copia ilícita, pero no basta para concluir que toda la información técnica se obtuvo de manera lícita. Evitar incluir datos extraídos o instrucciones de extracción.
- **Modelos creados por la comunidad.** Pueden tener licencias específicas incluso cuando su origen sea un juego; pedir autorización antes de redistribuir modelos y texturas.
- **Logotipo y aportaciones de terceros.** Confirmar que SaberRig puede redistribuir el icono y que los autores/contribuyentes del código y los avisos GPL estén debidamente reconocidos.
- **Difusión pública, monetización y jurisdicción.** Podrían requerir un análisis jurídico específico. Las guías fan no sustituyen a los términos del servicio ni a los derechos de propiedad intelectual.

## Reglas de publicación recomendadas

1. Distribuir solamente el addon en Python, documentación y el logotipo cuya licencia esté confirmada; nunca incluir `.blend`, `.pmx`, `.fbx`, `.obj`, texturas o animaciones provenientes de juegos sin permiso específico.
2. Permitir que el usuario seleccione y cargue voluntariamente modelos/armatures locales, sin extracción automática ni acceso al cliente del juego.
3. Mostrar la no afiliación y aclarar que cada modelo necesita derechos de uso propios.
4. Mantener GPL y atribuciones del proyecto; verificar los SPDX antes de cambios cosméticos en las cabeceras.
5. Releer estas políticas antes de lanzar una nueva versión pública, ya que pueden modificarse.
